/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!***********************************************!*\
  !*** ./resources/js/orderrequest/finalize.js ***!
  \***********************************************/
window.onload = function () {
  init();
};

function init() {}
/******/ })()
;
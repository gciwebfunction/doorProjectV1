/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*********************************************!*\
  !*** ./resources/js/dashboard/manufdash.js ***!
  \*********************************************/
window.onload = function () {
  init();
};

function init() {}
/******/ })()
;
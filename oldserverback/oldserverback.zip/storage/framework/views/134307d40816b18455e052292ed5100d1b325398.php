<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('User Management')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">

        <form class=" g-3" action="/u" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row p-1 m-1">
                <div class="col">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label for="selectUserType" class="form-label">Type of user to create...</label>
                </div>
                <div class="col">
                    <input type="hidden" value="<?php echo e(old('selectedUserType')); ?>"
                           id="selectedUserTypeHidden">
                    <select class="form-select form-control" aria-label="User Creation" id="selectUserType"
                            name="selectedUserType">
                        <option class="userTypeEmptySelector" selected="selected">Select a user
                            type...
                        </option>
                        <?php if(auth()->check() && auth()->user()->hasPermission('c_distributor')){?>
                        <option id="distributorSelector" value="distributor">Create a distributor user
                        </option>
                        <?php } ?>
                        <?php if(auth()->check() && auth()->user()->hasPermission('c_direct_dealer')){?>
                        <option id="dealerSelector" value="dealer">Create a dealer user</option>
                        <?php } ?>
                        <?php if(auth()->check() && auth()->user()->hasPermission('c_direct_dealer')){?>
                        <option id="directdealerSelector" value="dealer">Create a direct dealer user</option>
                        <?php } ?>
                        <?php if(auth()->check() && auth()->user()->hasPermission('c_sales_manager')){?>
                        <option id="salesManagerSelector" value="sales_manager">Create a sales manager
                            user
                        </option>
                        <?php } ?>
                        <?php if(auth()->check() && auth()->user()->hasPermission('c_sales_user')){?>
                        <option id="salesSelector" value="sales">Create a sales user</option>
                        <?php } ?>
                        <?php if(auth()->check() && auth()->user()->hasPermission('c_manuf_user')){?>
                        <option id="manufacturerSelector" value="manufacturer">Create a manufacturer
                            user
                        </option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="row  notADistributor m-1 p-1 d-none">
                <div class="col-4 mt-1">
                    <label for="selectedDistributor" class="form-label">Select Distributor</label>
                </div>
                <div class="col">
                    <select name="selectedDistributor" id="selectedDistributor"
                            class="form-select form-control">
                        <?php $__currentLoopData = $distributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($distributor): ?>

                                
                                <option value="<?php echo e($distributor->id); ?>"><?php echo e($distributor->name); ?></option>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="container py-4 standardUser d-none"
                 style="max-width: 700px; border:1px solid lightgray">
                <h5>Basic Info</h5>
                <hr/>
                <div class="row p-1 m-1">
                    <div class="col">
                        <label for="email" class="form-label">Email (This is your login)</label>
                    </div>
                    <div class="col">
                        <input type="email"
                               class="form-control<?php echo e($errors->has('email') ? ' is-invalid': ''); ?>"
                               id="email"
                               name="email"
                               value="<?php echo e(old('email')); ?>"
                               autocomplete="email">
                    </div>
                </div>
                <div class="row p-1 m-1">
                    <div class="col">
                        <label for="name" class="form-label">Name</label>
                    </div>
                    <div class="col">
                        <input type="text"
                               class="form-control<?php echo e($errors->has('name') ? ' is-invalid': ''); ?>"
                               id="name"
                               name="name"
                               value="<?php echo e(old('name')); ?>"
                               autocomplete="name">
                    </div>
                </div>
                <div class="row p-1 m-1">
                    <div class="col">
                        <label for="password" class="form-label">Password</label>
                    </div>
                    <div class="col">
                        <input type="password"
                               class="form-control"
                               id="password"
                               name="password">
                    </div>
                </div>
                <div class="row p-1 m-1">
                    <div class="col">
                        <label for="passwordConfirm" class="form-label">Password Confirmation</label>
                    </div>
                    <div class="col">
                        <input type="password"
                               class="form-control"
                               id="password_confirmation"
                               name="password_confirmation">
                    </div>
                </div>
            </div>

            <div class="container py-4 standardUser d-none"
                 style="border:1px solid lightgray;max-width: 700px;">
                <h5><span class="title_user_type"></span> Information</h5>
                <hr/>
                <div class="row p-1 m-1">
                    <div class="col">
                        <label for="distributorName" class="form-label"><span class="title_user_type"></span> Name</label>
                    </div>
                    <div class="col">
                        <input type="text"
                               class="form-control<?php echo e($errors->has('distributorName') ? ' is-invalid': ''); ?>"
                               id="distributorName"
                               name="distributorName"
                               value="<?php echo e(old('distributorName')); ?>"
                               autocomplete="distributorName">
                    </div>
                </div>
                <div class="row p-1 m-1 ">
                    <div class="col">
                        <label for="contactPerson" class="form-label">Contact Person</label>
                    </div>
                    <div class="col">
                        <input type="text"
                               class="form-control<?php echo e($errors->has('contactPerson')?' is-invalid': ''); ?>"
                               id="contactPerson"
                               name="contactPerson"
                               value="<?php echo e(old('contactPerson')); ?>">
                    </div>
                </div>
                <div class="row p-1 m-1 ">
                    <div class="col">
                        <label for="contactPersonPhone" class="form-label">Contact Phone</label>
                    </div>
                    <div class="col">
                        <input type="tel"
                               class="form-control<?php echo e($errors->has('contactPersonPhone')?' is-invalid': ''); ?>"
                               id="contactPersonPhone"
                               name="contactPersonPhone"
                               value="<?php echo e(old('contactPersonPhone')); ?>">
                    </div>
                </div>
                <div class="row p-1 m-1 ">
                    <div class="col">
                        <label for="contactPerson2" class="form-label">Alt. Contact Person</label>
                    </div>
                    <div class="col">
                        <input type="text"
                               class="form-control<?php echo e($errors->has('contactPerson2')?' is-invalid': ''); ?>"
                               id="contactPerson2"
                               name="contactPerson2"
                               value="<?php echo e(old('contactPerson2')); ?>">
                    </div>
                </div>
                <div class="row p-1 m-1 ">
                    <div class="col">
                        <label for="contactPersonPhone2" class="form-label">Alt. Contact Phone</label>
                    </div>
                    <div class="col">
                        <input type="tel"
                               class="form-control<?php echo e($errors->has('contactPersonPhone2')?' is-invalid': ''); ?>"
                               id="contactPersonPhone2"
                               name="contactPersonPhone2"
                               value="<?php echo e(old('contactPersonPhone2')); ?>">
                    </div>
                </div>
            </div>

            <div class="container py-4 d-none standardUser"
                 style="max-width:700px; border: 1px solid lightgray">
                <h5>Shipping Address</h5>
                <hr/>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="address">Address</label>
                    </div>
                    <div class="col">
                        <input type="text" id="address"
                               class="form-control<?php echo e($errors->has('address')?' is-invalid':''); ?>"
                               name="address" value="<?php echo e(old('address')); ?>" placeholder="123 Main St.">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="address2">Address 2</label>
                    </div>
                    <div class="col">
                        <input type="text" id="address2"
                               class="form-control<?php echo e($errors->has('address2')?' is-invalid':''); ?>"
                               name="address2" value="<?php echo e(old('address2')); ?>" placeholder="Apt / Suite #">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="state">State</label>
                    </div>
                    <div class="col">
                        <select id="state" name="state"
                                class="form-control<?php echo e($errors->has('state')?' is-invalid':''); ?>">
                            <?php $__currentLoopData = $usStates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="Taxes">Taxes</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="inputCity">City</label>
                    </div>
                    <div class="col">
                        <input type="text" id="inputCity"
                               class="form-control<?php echo e($errors->has('inputCity')?' is-invalid':''); ?>"
                               name="inputCity" value="<?php echo e(old('inputCi ty')); ?>" placeholder="Cityville">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="inputZip">Zip Code</label>
                    </div>
                    <div class="col">
                        <input type="text" id="inputZip"
                               class="form-control<?php echo e($errors->has('inputZip')?' is-invalid':''); ?>"
                               name="inputZip" value="<?php echo e(old('inputZip')); ?>" placeholder="12345-1234">
                    </div>
                </div>
            </div>
            <?php if(auth()->check() && auth()->user()->hasPermission('c_user')){?>
            <div class="row bottom-button-bar standardUser d-none" role="alert">
                <div class="col">
                    <button class="btn btn-primary" type="submit">Create User</button>
                </div>
            </div>
            <?php } ?>
        </form>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/user/utility.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/user/create.blade.php ENDPATH**/ ?>
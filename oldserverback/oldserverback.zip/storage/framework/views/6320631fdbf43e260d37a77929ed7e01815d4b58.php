<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Create a Product')); ?>

     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <h4 class="text-center">Product Creation</h4>
        <div id="errorContainer">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <hr/>
        <form class="row g-3" action="/p/doorflow/one" method="POST" enctype="multipart/form-data"
              id="addProductForm">
            <?php echo csrf_field(); ?>

            <input type="hidden" value="1" id="optionalSelectCount" name="optional_select_count">

            <div style="display: grid; grid-template-columns: 1fr 3fr">
                <div class="left-1/3" style="margin-right: 2px; padding-right: 1px">
                    <div class="alert alert-success" role="alert">
                        <h2 class="alert-heading"><strong>Create a Product</strong></h2>
                        <p>Add a new product to the catalog, configure available options.</p>
                        <hr>

                    </div>
                    <div class="col-lg p-3 m-3">
                        <label class="form-label" for="category_id">Category for the product...</label>
                        <?php if(isset($categories)): ?>
                            <select type="text" id="categorySelection" name="product_category"
                                    class="form-control" style="min-width: 300px ">
                                <option value="0">Select a category...</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($door) && $door->category->id==$category->id): ?>
                                        <option selected
                                                value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php elseif(old('product_category')==$category->id): ?>
                                        <option selected
                                                value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php else: ?>
                                        <option
                                            value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <h2>Error loading category data, contact support.</h2>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="right-2/3 d-none" id="doorProductContainer"
                     style="margin-left: 4px; padding-left: 3px;border-left: 1px solid black"
                     id="rightContainer">

                    <div id="doorTypeListContainer">
                        <div class="row p-1 m-1">
                            <div class="col">
                                <label class="form-label" for="door_type"
                                       id="subCategoryNameLabel">Sub-category...</label>
                            </div>
                        </div>
                        <div class="row p-1 m-1">
                            <div class="col">
                                <input type="text" list="subCatList"
                                       <?php if(!isset($door)): ?>
                                       disabled
                                       <?php endif; ?>
                                       id="doorTypesList" name="door_type"
                                       class="form-control" style="min-width: 300px">
                                <datalist id="subCatList">
                                    <?php $__currentLoopData = $doorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doorType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($door) && $door->doorType->id==$doorType->id): ?>
                                            <option
                                                class="doorTypeOption doorTypeCategory-<?php echo e($doorType->category_id); ?>"
                                                value="<?php echo e($doorType->door_type_pretty_name); ?>"
                                                selected><?php echo e($doorType->door_type_pretty_name); ?></option>
                                        <?php else: ?>
                                            <option
                                                class="doorTypeOption doorTypeCategory-<?php echo e($doorType->category_id); ?>"
                                                value="<?php echo e($doorType->door_type_pretty_name); ?>"><?php echo e($doorType->door_type_pretty_name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            </div>
                        </div>
                    </div>

                    <div id="additionalDoorSpecifierContainer">
                        <div class="row p-1 m-1">
                            <div class="col">
                                <label class="form-label" for="additionalDoorSpec" id="subCategoryNameLabel">Optional
                                    Select
                                    (ie.
                                    Full Lite)...</label>
                            </div>
                        </div>
                        <div class="row p-1 m-1">
                            <div class="col">
                                <input type="text" id="additionalDoorSpec-0" name="additional_door_spec-0" disabled
                                       class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg p-1 m-1" id="additionalDoorSpecifierButtonContainer">
                        <button class="btn btn-primary" id="addSpecifierInputField" disabled>Add another optional
                            selection
                        </button>
                    </div>
                    <div id="doorNameContainer">

                        <div class="row p-1 m-1">
                            <div class="col">

                                <label class="form-label" for="doorName" id="doorNameLabel">Product Name or
                                    Identifier</label>
                            </div>
                        </div>
                        <div class="row p-1 m-1">
                            <div class="col">
                                <?php if(isset($door)): ?>
                                    <input type="text" value="<?php echo e($door->name); ?>" class="form-control"
                                           id="doorName" name="door_name">
                                <?php else: ?>
                                    <input type="text" value="" class="form-control"
                                           id="doorName" name="door_name">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row p-1 m-1">
                        <div class="col">
                            <label class="form-label" for="doorPanelCount" id="panelCountLabel">Panel Count</label>
                        </div>
                    </div>
                    <div class="row p-1 m-1">
                        <div class="col">
                            <input type="number" name="panel_count" id="doorPanelCount" class="form-control"
                                   value="<?php echo e($door->panel_count??1); ?>">
                        </div>
                    </div>
                    <?php if(isset($door)): ?>
                        <?php $__currentLoopData = $door->doorNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg p-1 m-1" id="doorTypeContainer-<?php echo e($loop->index); ?>">
                                <label class="form-label" for="doorNameType-<?php echo e($loop->index); ?>"
                                       id="doorNameTypeLabel-<?php echo e($loop->index); ?>">Name or Type (ie.
                                    Inswing or XO, XOOX)</label>
                                <input type="text" value="<?php echo e($name->door_name_or_type); ?>"
                                       id="doorNameType-<?php echo e($loop->index); ?>" name="door_name_type-<?php echo e($loop->index); ?>"
                                       class="form-control productFormElement dataFieldDoorProduct"
                                       style="min-width: 300px"/>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-lg p-1 m-1" id="doorTypeContainer-0">
                            <label class="form-label" for="doorNameType-0" id="doorNameTypeLabel-0">Name or Type (ie.
                                Inswing or XO, XOOX)</label>
                            <input type="text"
                                   id="doorNameType-0" name="door_name_type-0"
                                   class="form-control productFormElement dataFieldDoorProduct"
                                   style="min-width: 300px"/>
                        </div>
                        <div class="col-lg p-1 m-1" id="doorTypeImageContainer-0">
                            <label class="form-label" for="doorNameType" id="doorNameTypeLabel">
                                Add Image for Type
                            </label>
                            <input type="file"
                                   style="margin-left: 20px;"
                                   name="door_type_image-0"
                                   aria-describedby="doorTypeImage"
                                   id="door_type_image-0"
                                   class="form-control-file">
                            <?php if($errors->has('category_image')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('door_type_image-0')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div id="addTypeContainer" class="col-lg p-3 m-3"></div>
                    <div class="col-lg p-1 m-1" id="addTypeAndImageButtonContainer">
                        <button class="btn btn-primary" id="addTypeAndImageDivButton"
                                disabled>Add Another Type
                        </button>
                        <input type="hidden" id="typeCount" name="type_count" value="1">
                    </div>

                </div>
                <div class="right-2/3 d-none" id="otherProductContainer"
                     style="margin-left: 4px; padding-left: 3px;border-left: 1px solid black"
                     id="rightContainer">
                    <div class="row p-1 m-1">
                        <div class="col">
                            <label class="form-label" for="otherProductName">Product Name</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control dataFieldOtherProduct" name="product_name">
                        </div>
                    </div>
                    <div class="row p-3 m-3">
                        <div class="col">
                            <label class="form-label" for="otherProductImage">Product Image</label>
                        </div>
                        <div class="col">
                            <input type="file"
                                   style="margin-left: 20px;"
                                   name="other_product_image"
                                   aria-describedby="otherProductImage"
                                   id="otherProductImage"
                                   class="form-control-file">
                        </div>
                    </div>
                    <div class="row p-3 m-3">
                        <div class="col">
                            <label class="form-label" for="productDescription">Product Description</label>
                        </div>
                        <div class="col">
                            <textarea cols="40" rows="5" name="product_description" id="productDescription"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="row bottom-button-bar" role="alert">
        <div class="col">
            <button class="btn btn-primary" id="continueButton"> Continue...</button>
        </div>
    </div>

    <div style="height: 50px"></div>

    <div class="d-none">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="categoryValuesHidden">
                <?php echo e($category->id); ?>,<?php echo e($category->category_name); ?>

            </div>
            <input type="hidden" id="categoryTypeHolder-<?php echo e($category->id); ?>" value="<?php echo e($category->type); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/product/door/utility1.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/product/create/doorflow/stepone.blade.php ENDPATH**/ ?>
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Product Management') }}
        </h2>
    </x-slot>

    <div class="container py-4">
        <div class="text-end " style="margin-right: 20px; text-align: right; position: fixed; right: 50px; top: 120px; z-index: 1000000">
            <a href="{{route('pcreatedoorflowstepone')}}">
                <button class="btn btn-primary mb-3">Add New Product
                </button>
            </a>
        </div>
        <div class="card">
            <h5 class="card-header">Product List</h5>
            <div class="card-body">

                <div id="message" class="text-center">
                </div>

                <div id="centerFloatDiv" class="d-none">
                    <div class="divFloat" id="divFloat" style="text-align: center"></div>
                </div>

                <input type="hidden" value="" id="deleteLocation">

                @if(isset($doors))
                    <table class="table table-striped" id="productTable" style="width: 100%">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Product</th>
                            <th>Type</th>
                            <th>Names</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($doors as $product)
                            <tr class="" style="cursor: pointer" id="rowProductId-{{$product->id}}">
                                <td class="d-none">{{$product->id}}</td>
                                <td class="alert-danger delete">
                                    <div data-bs-toggle="modal" data-bs-target="#deleteProduct{{$product->id}}"
                                         style="text-align: center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#FF0000"
                                             class="bi bi-x" viewBox="0 0 16 16">
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                        </svg>
                                    </div>
                                    <div class="modal" id="deleteProduct{{$product->id}}" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Delete Order Request</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete product: {{$product->name}}?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">
                                                        Cancel
                                                    </button>
                                                    <button type="button" class="btn btn-primary"
                                                            onclick="deleteProduct({{$product->id}}, '{{$product->name}}')">
                                                        Delete Product
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>{{$product->name}}</td>
                                <td>{{$product->doorType->door_type_pretty_name??' '}}</td>
                                <td>
                                    @foreach($product->doorNames as $name)
                                        @if($loop->index>0)
                                            ,
                                        @endif
                                        {{$name->door_name_or_type}}
                                    @endforeach</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                @endif
                @if(isset($products))
                    <table class="table table-striped" id="product2Table" style="width: 100%">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Product</th>
                            <th>Type</th>
                            <th>Names</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($products as $product)
                            <tr class="" style="cursor: pointer" id="rowProductId-{{$product->id}}">
                                <td class="d-none">{{$product->id}}</td>
                                <td class="alert-danger delete">
                                    <div data-bs-toggle="modal" data-bs-target="#deleteProduct{{$product->id}}"
                                         style="text-align: center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#FF0000"
                                             class="bi bi-x" viewBox="0 0 16 16">
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                        </svg>
                                    </div>
                                    <div class="modal" id="deleteProduct{{$product->id}}" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Delete Order Request</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete product: {{$product->name}}?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">
                                                        Cancel
                                                    </button>
                                                    <button type="button" class="btn btn-primary"
                                                            onclick="deleteProduct({{$product->id}}, '{{$product->name}}')">
                                                        Delete Product
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>{{$product->product_name}}</td>
                                @if(isset($product->category))
                                    <td>{{$product->category->category_name}}</td>
                                @else
                                    <td>No Category - Update product, bad data</td>
                                @endif
                                <td></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
        <div class="text-end " style="margin-right: 20px; text-align: right">
            <a href="{{route('pcreatedoorflowstepone')}}">
                <button class="btn btn-primary mb-3">Add New Product
                </button>
            </a>
        </div>
    </div>
    @section('scripts')
        <script src="{{ asset('js/product/view.js') }}" defer></script>
    @stop
</x-app-layout>

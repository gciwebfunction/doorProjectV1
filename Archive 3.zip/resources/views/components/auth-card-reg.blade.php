<div class=" flex flex-col sm:justify-center items-center pt-6 sm:pt-0">
    <div>
        {{ $logo }}
    </div>
    <h3 class="u-custom-font u-font-montserrat u-text u-text-default u-text-1"><b>Register
        </b>
    </h3>
    <div class="login-grid u-clearfix u-expanded-width u-gutter-0 u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
            <div class="u-layout-row">
                <div class="u-align-left u-container-style u-image u-layout-cell u-size-30 u-image-1" data-image-width="1280" data-image-height="997">
                    <div class="u-container-layout u-container-layout-1"></div>
                </div>
                <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-2">
                    <div class="u-container-layout u-container-layout-2">
                        <div class="product-form u-expanded-width u-form u-white u-form-1">
                            {{ $slot }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

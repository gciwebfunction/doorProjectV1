<!-- Navigation Links -->
<div class="container sticky-top bg-white" style="min-width: 900px; border-bottom: 1px solid gray">
    <header
        class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4  bg">
        <a class="navbar-brand" href="#">GCI</a>

        <ul class="nav mb-2 justify-content-center mb-md-0">
            @can(['c_sales_manager','c_distributor','c_sales_user','c_direct_dealer'])
                <x-nav-link :href="route('manufdashboard')" :active="request()->routeIs('manufdashboard')">
                    {{ __('Dashboard') }}
                </x-nav-link>
            @else
                <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                    {{ __('Dashboard') }}
                </x-nav-link>
            @endcan
            @can('r_category')
                <x-nav-link :href="route('cview')" :active="request()->routeIs('cview')">
                    {{ __('Categories') }}
                </x-nav-link>
            @endcan
            @can('c_product')
                <x-nav-link :href="route('pview')" :active="request()->routeIs('pview')">
                    {{ __('Product Management') }}
                </x-nav-link>
            @endcan
            @can('r_user')
                <x-nav-link :href="route('uview')" :active="request()->routeIs('uview')">
                    {{ __('Users') }}
                </x-nav-link>
            @endcan
            @can('cf_order')
                <x-nav-link :href="route('oview')" :active="request()->routeIs('oview')">
                    {{ __('Orders') }}
                </x-nav-link>
            @endcan

            @can('r_order')
                <x-nav-link :href="route('cartviewdoor',['shoppingCartId'=>0])"
                            :active="request()->routeIs('cartviewdoor',['shoppingCartId'=>0])">
                    Cart
                </x-nav-link>
            @endcan

        </ul>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <x-responsive-nav-link :href="route('logout')"
                                   onclick="event.preventDefault();
                                        this.closest('form').submit();">
                <ul class="navbar-nav me-auto mb-2 mb-md-0" style="padding-right: 10px;">
                    <li class="nav-item">{{ __('Log Out') }}</li>
                </ul>
            </x-responsive-nav-link>
        </form>

        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                    data-bs-toggle="dropdown" aria-expanded="false">
                {{ Auth::user()->name }}
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <li>{{ Auth::user()->email }}</li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li>
                    <x-responsive-nav-link :href="route('permviewuser')">
                        {{ __('User Details') }}
                    </x-responsive-nav-link>
                </li>
            </ul>
        </div>
    </header>
</div>











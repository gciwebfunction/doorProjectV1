
<script src="<?php echo e(asset('js/bootstrap.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/utility.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/layouts/script.blade.php ENDPATH**/ ?>
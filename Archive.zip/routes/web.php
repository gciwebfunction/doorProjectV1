<?php

use App\Models\Constants;
use Illuminate\Support\Facades\Route;
use App\Models\Product\Door\AdditionalOption;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Route::get('/o/EditManufacturerForm', [App\Http\Controllers\Cart\OrderController::class, 'EditManufacturerForm']);
Route::get('/o/test', [App\Http\Controllers\Cart\OrderController::class, 'test']);

Route::get('/about', function () {
    return view('aboutus');
})->name('aboutus');

Route::get('/test', function () {
    return view('test');
})->name('test');



Route::get('/dashboard', function () {
    $service = new \App\Service\CartService();
    $shoppingCart = $service->getUserCart(auth()->user()->id);
    return view('dashboard',
        ['categories' => \App\Models\Category::all(),
            'doorTypes' => \App\Models\Product\Door\DoorType::all(),
            'products' => \App\Models\Product::all(),
            'shoppingCart' => $shoppingCart,
            'status' => \App\Models\Order\Status::all(),
            'orderRequests' => \App\Models\Order\OrderRequest::where('user_id', auth()->user()->id)->get()]);
})->middleware(['auth'])->name('dashboard');

Route::get('/manufdashboard', function () {
    $service = new \App\Service\CartService();
    $shoppingCart = $service->getUserCart(auth()->user()->id);
    return view('manufdashboard',
        ['categories' => \App\Models\Category::all(),
            'products' => \App\Models\Product::all(),
            'doorTypes' => \App\Models\Product\Door\DoorType::all(),
            'shoppingCart' => $shoppingCart,
            'status' => \App\Models\Order\Status::all(),
            'orderRequests' => \App\Models\Order\OrderRequest::all(),
            'orders' => \App\Models\Order\Order::all(),
        ]);
})->middleware(['auth'])->name('manufdashboard');


Route::get('/', function () {
    return view('welcome');
});

Route::get('/u/create', 'App\Http\Controllers\DetailedUserController@create')
    ->middleware('groups:manuf-grp')->name('ucreate');

Route::post('/u', 'App\Http\Controllers\DetailedUserController@store')
    ->middleware('groups:manuf-grp')->name('ustore');

Route::post('/u/update', 'App\Http\Controllers\DetailedUserController@update')
    ->middleware('groups:manuf-grp,dist-grp')->name('uupdate');

Route::get('/u/view', 'App\Http\Controllers\DetailedUserController@view')
    ->middleware('permissions:r_user')->name('uview');

Route::get('/u/{id}', '\App\Http\Controllers\DetailedUserController@show')
    ->middleware('groups:manuf-grp')->name('ushow');;

Route::get('/u/toggleuser/{id}', '\App\Http\Controllers\DetailedUserController@toggle')
    ->middleware('auth')->name('utoggle');;

/*$categories = \App\Models\Category::getTable('categories')
    ->join('products', 'products.category_id', '=', 'categories.id')
    ->select('categories.*')
    ->get();*/


Route::get('/c', function () {
    return view('category.view', [ 'categories' => DB::table('categories')
        ->leftjoin('products', 'products.category_id', '=', 'categories.id')
        ->select('categories.id','categories.category_name' , 'categories.category_note',DB::raw('count(products.id) as products_sum '))
        ->groupBy(DB::raw("categories.id"))
        ->get() ] );
    //return view('category.view', [ 'categories' => \App\Models\Category::all()]);

})->middleware('permissions:r_category')->name('cview');

Route::get('/c/create', '\App\Http\Controllers\CategoryController@create')->name('ccreate');

Route::post('/c', '\App\Http\Controllers\CategoryController@store')->name('cstore');

Route::get('/c/{id}', '\App\Http\Controllers\CategoryController@show')->name('cshow');

Route::get('/c/edit/{category_id}', function ($category_id) {
    $category = \App\Models\Category::findOrFail($category_id);
    return view('category.edit', [
        'category' => $category,
    ]);
})->middleware('auth')
    ->name('categoryedit');

Route::post('/c/update', 'App\Http\Controllers\CategoryController@update')->middleware('auth')
    ->name('categoryupdate');

Route::get('/c/delete/{categoryId}', '\App\Http\Controllers\CategoryController@deleteCategory')
    ->middleware('auth')
    ->name('cdelete');

Route::get('/p', function () {
    return view('product.viewdoor', [
        'doors' => \App\Models\Product\Door\Door::all(),
        'products' => \App\Models\Product::all()]);
})->middleware('auth')->name('pview');

Route::get('/p/createflowstepone', '\App\Http\Controllers\Product\ProductController@createFlowStepOne')->name('pcreateflowstepone');
Route::get('/p/createflowsteptwo/{id}', '\App\Http\Controllers\Product\ProductController@createFlowStepTwo')->name('pcreateflowsteptwo');

Route::get('/p/createdoorflowstepone', '\App\Http\Controllers\Product\Door\DoorController@createDoorFlowStepOne')->name('pcreatedoorflowstepone');
Route::get('/p/createdoorflowsteptwo/{id}', '\App\Http\Controllers\Product\Door\DoorController@createDoorFlowStepTwo')
    ->name('pcreatedoorflowsteptwo');
Route::get('/p/createdoorflowstepthree/{id}', function ($id) {
    ///dd(\App\Models\Product\Door\Door::findOrFail($id));
    return view('product.create.doorflow.stepthree',
        ['door' => \App\Models\Product\Door\Door::findOrFail($id)]);
})->middleware('auth')
    ->name('pcreatedoorflowstepthree');
Route::get('/p/createdoorflowstepfour/{id}', function ($id) {
    return view('product.create.doorflow.stepfour',
        ['door' => \App\Models\Product\Door\Door::findOrFail($id)]);
})->middleware('auth')
    ->name('pcreatedoorflowstepfour');
Route::get('/p/createdoorflowstepfive/{id}', function ($id) {
    return view('product.create.doorflow.stepfive',
        ['door' => \App\Models\Product\Door\Door::findOrFail($id)]);
})->middleware('auth')
    ->name('pcreatedoorflowstepfive');

Route::post('/p/doorflow/one', '\App\Http\Controllers\Product\Door\DoorController@storeDoorFlowStepOne')
    ->middleware('auth')
    ->name('pstoredoorflowstepone');
Route::post('/p/doorflow/two', '\App\Http\Controllers\Product\Door\DoorController@storeDoorFlowStepTwo')
    ->middleware('auth')
    ->name('pstoredoorflowsteptwo');
Route::post('/p/doorflow/three', '\App\Http\Controllers\Product\Door\DoorController@storeDoorFlowStepThree')
    ->middleware('auth')
    ->name('pstoredoorflowstepthree');
Route::post('/p/doorflow/four', '\App\Http\Controllers\Product\Door\DoorController@storeDoorFlowStepFour')
    ->middleware('auth')
    ->name('pstoredoorflowstepfour');
Route::post('/p/doorflow/five', '\App\Http\Controllers\Product\Door\DoorController@storeDoorFlowStepFive')
    ->middleware('auth')
    ->name('pstoredoorflowstepfive');

Route::get('/p/editdoorflowstepone/{id}', '\App\Http\Controllers\Product\Door\DoorController@editDoorFlowStepOne')->middleware('auth')->name('peditdoorflowstepone');
Route::get('/p/editdoorflowsteptwo/{id}', '\App\Http\Controllers\Product\Door\DoorController@editDoorFlowStepTwo')->middleware('auth')->name('peditdoorflowsteptwo');
Route::get('/p/editdoorflowstepthree/{id}', function ($id) {
    $door = \App\Models\Product\Door\Door::findOrFail($id);
    $uniqueOptions = [];
    foreach ($door->additionalOptions as $additionalOption) {
        $uniqueOptions[] = $additionalOption->group_name;
    }
    return view('product.edit.doorflow.stepthree',
        ['door' => $door,
            'uniqueOptionList' => array_unique($uniqueOptions),
            'glassOptions' => AdditionalOption::where('group_name', 'GLASS_OPTION')->where('door_id', $id)->get(),
//    @case('GLASS_OPTION')
//                                                        Glass Option
//                                                        @break
//    @case('GLASS_LOWE_OPTION')
//                                                        Glass Lowe Option
//                                                        @break
//    @case('GLASS_DEPTH_OPTION')
//                                                        Glass Depth Option
//                                                        @break
//    @case('HANDLE_TYPE_OPTION')
//                                                        Handle Type Option
//                                                        @break
//    @case('LOCK_SET_OPTION')
//                                                        Lock Set Option
//                                                        @break
//    @case('HARDWARE_COLOR_OPTION')
//                                                        Hardware Color Option
//                                                        @break
//    @case('FRAME_THICKNESS_OPTION')
//                                                        Frame Thickness Option
//                                                        @break
//    @case('GLASS_GRID')
//                                                        Glass Grid
        ]);
})->middleware('auth')->name('peditdoorflowstepthree');

Route::post('/p/editdoorflow/updatestepone', '\App\Http\Controllers\Product\Door\DoorController@updateDoorFlowStepOne')
    ->middleware('auth')
    ->name('pupdatedoorstepone');
Route::post('/p/editdoorflow/updatesteptwo', '\App\Http\Controllers\Product\Door\DoorController@updateDoorFlowStepTwo')
    ->middleware('auth')
    ->name('pupdatedoorsteptwo');
Route::post('/p/editdoorflow/updatestepthree', '\App\Http\Controllers\Product\Door\DoorController@updateDoorFlowStepThree')
    ->middleware('auth')
    ->name('pupdatedoorstepthree');

Route::get('/p/deleteAddOnOption/{addOnOptionId}/{sizeCodeId}', 'App\Http\Controllers\Product\OptionController@deleteAddOnOptionSizeCode')
    ->middleware('auth')
    ->name('pdeleteaddonoption');

Route::get('/p/deleteFinishOption/{finishOptionId}/{sizeCodeId}', 'App\Http\Controllers\Product\OptionController@deleteFinishOptionSizeCode')
    ->middleware('auth')
    ->name('pdeletefinishoption');

Route::get('/p/deleteDoorOption/{addOnOptionId}', 'App\Http\Controllers\Product\OptionController@deleteDoorOption')
    ->middleware('auth')
    ->name('pdeletedooroption');

Route::get('/p/deleteDoorHandling/{handlingId}', 'App\Http\Controllers\Product\OptionController@deleteDoorHandling')
    ->middleware('auth')
    ->name('pdeletedoorhandling');

Route::get('/p/deleteInteriorColor/{colorId}', 'App\Http\Controllers\Product\OptionController@deleteInteriorColor')
    ->middleware('auth')
    ->name('pdeleteinteriorcolor');

Route::get('/p/deleteDoorMeasurement/{measurementId}', 'App\Http\Controllers\Product\OptionController@deleteDoorMeasurement')
    ->middleware('auth')
    ->name('pdeletemeasurement');

Route::get('/p/delete/{productId}', '\App\Http\Controllers\Product\ProductController@deleteProduct')
    ->middleware('auth')
    ->name('pdelete');

// Route::get('/p/deleteDoor/{doorId}', '\App\Http\Controllers\Product\Door\DoorController@deleteDoor')
//     ->middleware('auth')
//     ->name('pdeletedoor');

Route::get('/p/deleteDoor/{id}', '\App\Http\Controllers\Product\Door\DoorController@deleteDoor');


Route::post('/p/flow/one', '\App\Http\Controllers\Product\ProductController@storeFlowStepOne')
    ->middleware('auth')
    ->name('pstoreflowstepone');
Route::post('/p/flow/two', '\App\Http\Controllers\Product\ProductController@storeFlowStepTwo')
    ->middleware('auth')
    ->name('pstoreflowsteptwo');
Route::post('/p/flow/addonoption/{productId}', '\App\Http\Controllers\Product\OptionController@storeNewAddOnOption')
    ->middleware('auth')
    ->name('pstoreflowaddonoption');
Route::post('/p/flow/finishoption/{productId}', '\App\Http\Controllers\Product\OptionController@storeNewFinishOption')
    ->middleware('auth')
    ->name('pstoreflowfinishoption');
Route::get('/p/flow/changecategory/{productId}', function ($productId) {
    return view('product.create.flow.changecategory', [
        'product' => \App\Models\Product::findOrFail($productId),
        'categories' => \App\Models\Category::all(),
    ]);
})
    ->middleware('auth')
    ->name('pchangecategory');
Route::post('/p/flow/three', '\App\Http\Controllers\Product\ProductController@storeFlowSaveCategoryChanges')
    ->middleware('auth')
    ->name('pstoreflowstepthree');

Route::get('/p/{productId}', function ($productId) {
    return view('product.viewone', [
        'product' => \App\Models\Product::findOrFail($productId)]);
})
    ->middleware('auth')
    ->name('pshow');

require __DIR__ . '/auth.php';

Route::post('/perm/add/{groupId}', 'App\Http\Controllers\Auth\PermissionController@addPermissionToGroup')->name('permadd');
Route::get('/perm', '\App\Http\Controllers\Auth\PermissionController@view')->name('permview');
Route::get('/perm/viewuser', '\App\Http\Controllers\Auth\PermissionController@getPermissionsForUser')->name('permviewuser');


Route::post('/sc/addObject/{productId}/{shoppingCartId}',
    '\App\Http\Controllers\Cart\CartController@addItemToCart')
    ->middleware('auth')
    ->name('cartaddobject');
Route::post('/sc/addDoor/{productId}/{shoppingCartId}',
    '\App\Http\Controllers\Cart\CartController@addDoorToCart')
    ->middleware('auth')
    ->name('cartadddoor');
Route::get('/sc/view/{shoppingCartId}', '\App\Http\Controllers\Cart\CartController@viewCart')
    ->middleware('auth')
    ->name('cartview');
Route::get('/scdoor/view/{shoppingCartId}', '\App\Http\Controllers\Cart\CartController@viewDoorCart')
    ->middleware('auth')
    ->name('cartviewdoor');
Route::get('/sc/clearcart/{shoppingCartId}', '\App\Http\Controllers\Cart\CartController@clearCart')
    ->middleware('auth')
    ->name('cartclear');
Route::get('/sc/deleteItem/{id}', '\App\Http\Controllers\Cart\CartController@deleteCartItem')
    ->middleware('auth')
    ->name('scdeleteitem');
Route::get('/sc/deleteDoorItem/{id}', '\App\Http\Controllers\Cart\CartController@deleteCartDoorItem')
    ->middleware('auth')
    ->name('scdeletedooritem');

Route::get('/sc/door/{id}/{doorid}', function ($id, $doorId) {
        //$dorr  = \App\Models\Product\Door\Door::findOrFail($doorId)->toArray();
        //dd($dorr);

        return view('shoppingcart.doortuning',
            [
            'door'              => \App\Models\Product\Door\Door::findOrFail($doorId),
            'shoppingCart'      => \App\Models\Order\ShoppingCart::findOrFail($id),
            'doorHandlings2'    => \App\Models\Product\Door\DoorHandling::where([
                'door_id'       => $doorId,
                'handle_type'   => 1])->get(),
            'doorHandlings1'    => \App\Models\Product\Door\DoorHandling::where([
                'door_id'       => $doorId,
                'handle_type'   => 0])->get(),
            ]);
})->middleware('auth')
    ->name('shoppingcart.doortuning');


Route::get('/sc/product/{id}/{productId}', function ($id, $productId) {
    return view('shoppingcart.itemtuning',
        ['product' => \App\Models\Product::findOrFail($productId),
            'shoppingCart' => \App\Models\Order\ShoppingCart::findOrFail($id)]);
})->middleware('auth')
    ->name('shoppingcart.itemtuning');


Route::get('/or', 'App\Http\Controllers\Cart\OrderController@showOrderRequests')
    ->middleware('auth')
    ->name('orview');
Route::get('/or/manuf', 'App\Http\Controllers\Cart\OrderController@showManufOrderRequests')
    ->middleware('auth')
    ->name('ormanufview');
Route::get('/or/delete/{orId}', function ($orId) {
    \App\Models\Order\OrderRequest::findOrFail($orId)->delete();
    return redirect()->route('orview');
})->middleware('permissions:d_order_request')
    ->name('ordelete');
Route::get('/or/submit/{orId}', 'App\Http\Controllers\Cart\OrderController@submitOrderRequest')
    ->middleware('auth')
    ->name('orsubmit');
Route::get('/or/confirm/{orId}', 'App\Http\Controllers\Cart\OrderController@confirmOrderRequest')
    ->middleware('auth')
    ->name('orconfirm');
Route::post('/or/finalize', '\App\Http\Controllers\Cart\OrderController@createOrderRequestStepTwo')
    ->middleware('auth')
    ->name('orcreatefinalize');
// for creation of order request
Route::post('/or/{cartId}', '\App\Http\Controllers\Cart\OrderController@createOrderRequestStepOne')
    ->middleware('auth')
    ->name('orcreatestepone');
Route::get('/or/{orId}', function ($orId) {
    $orderRequest = \App\Models\Order\OrderRequest::findOrFail($orId);
    $usStates = Constants::getStates();
    return view('orderrequest.steptwo', [
        'orderRequest'  => $orderRequest,
        'usStates'      => $usStates,
    ]);
})->middleware('auth')
    ->name('orviewsteptwo');
Route::post('/or/confirmstepone/{orId}', 'App\Http\Controllers\Cart\OrderController@confirmStepOne')
    ->middleware('auth')
    ->name('orconfirmstepone');
Route::get('/or/view/{orId}', function ($orId) {
    return view('orderrequest.viewone', ['orderRequest' => \App\Models\Order\OrderRequest::findOrFail($orId)]);
})->middleware('auth')
    ->name('orviewone');

Route::post('/o/convert/{orId}', 'App\Http\Controllers\Cart\OrderController@convertOrderRequest')
    ->middleware('auth')
    ->name('oconvert');
Route::get('/o/view/{oId}', function ($oId) {
    $order = \App\Models\Order\Order::findOrFail($oId);
    return view('order.view', ['order' => $order, 'status' => \App\Models\Order\Status::all()]);
})->middleware('auth')
    ->name('oviewone');

// oview route name
Route::get('/o', 'App\Http\Controllers\Cart\OrderController@showOrders')
    ->middleware('auth')
    ->name('oview');

Route::get('/o/orPrint/{oId}', 'App\Http\Controllers\Cart\OrderController@orPrint')
    ->middleware('auth')
    ->name('orprint');


//Route::get('/o/Editmanufacturerform/{oId}', 'App\Http\Controllers\Cart\OrderController@Editmanufacturerform')
Route::get('/o/editManufacturerform/{oId}', 'App\Http\Controllers\Cart\OrderController@editManufacturerform')
    ->middleware('auth');


Route::post('/o/manufacturerReqconfirm/', 'App\Http\Controllers\Cart\OrderController@manufacturerReqconfirm')
    ->middleware('auth');
Route::get('/o/editManufacturereqconfirm/{orId}', 'App\Http\Controllers\Cart\OrderController@editManufacturereqconfirm')
    ->middleware('auth');


Route::get('/o/orderReqconfirm/{orId}', 'App\Http\Controllers\Cart\OrderController@orderReqconfirm')
    ->middleware('auth');
Route::get('/o/rejectOrderrequest/{orId}', 'App\Http\Controllers\Cart\OrderController@rejectOrderrequest')
    ->middleware('auth');



Route::post('/o/Editmanufacturerreq/', '\App\Http\Controllers\Cart\OrderController@Editmanufacturerreq');
Route::get('/o/Editmanufacturerdetailview/{orId}', '\App\Http\Controllers\Cart\OrderController@Editmanufacturerdetailview');
Route::get('/o/UpdateOrderRequest/{status}/{orReqId}', '\App\Http\Controllers\Cart\OrderController@UpdateOrderRequest');
Route::get('/o/Distributor_request_update/{status}/{orReqId}', '\App\Http\Controllers\Cart\OrderController@Distributor_request_update');






Route::get('/p/helper/door/{categoryName}', '\App\Http\Controllers\Product\Door\DoorHelperController@getDoorTypes')
    ->middleware('auth')
    ->name('productdoorhelper');

Route::get('edit/product/{id}', '\App\Http\Controllers\Product\ProductController@ProductEdit')->name('myproductedit');


Route::post('updateProduct', '\App\Http\Controllers\Product\ProductController@updateProduct')->name('updateProduct');



Route::get('/clear-cache', function() {
    Artisan::call('route:clear');
    Artisan::call('cache:clear');
    Artisan::call('view:clear');
    Artisan::call('config:clear');
    return "Artisan cleared";
});



Route::get('/config-cache', function() {
    Artisan::call('config:cache');
    return "Config Cache";
});

Route::get('/opt', function() {
    Artisan::call('optimize');
    return "optimized";
});

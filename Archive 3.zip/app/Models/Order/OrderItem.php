<?php

namespace App\Models\Order;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;

    public $fillable = [
        'order_id',
        'item',
        'prod_type',
        'prod',
        'spec',
        'width',
        'height',
        'panel_type',
        'door_type',
        'door_frame',
        'color_code',
        'glass_type',
        'glass_material',
        'glass_thickness',
        'handle',
        'lock_set_type',
        'lock_set_color',
        'predrill_type',
        'wall_thickness',
        'order',
        'quantity',
        'unit',
        'unit_price',
        'amount',
        'discount_type',
        'calculated_amount',
        'discount_amount',
    ];
}

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Order')); ?> <?php echo e($door->doorType->door_type_pretty_name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container  mt-4" style="min-width: 900px;">
        <h4 class="fw-bold">Configure your product... <?php echo e($door->name??''); ?></h4>

        <form action="/sc/addDoor/<?php echo e($door->id); ?>/<?php echo e($shoppingCart->id ?? 0); ?>" method="POST"
              id="cartItemForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="productId" name="product_id" value="<?php echo e($door->id); ?>">
            <input type="hidden" id="shoppingCartId" name="shopping_cart_id" value="<?php echo e($shoppingCart->id ?? ''); ?>">
            <input type="hidden" name="door_name_type_id_selection" id="doorNameTypeIdSelection"
                   value="<?php echo e(old('door_name_type_id_selection')); ?>">

            <div class="" style="position: fixed; top: 120px; right: 50px; font-weight: bold; z-index: 93822992;
            border: 1px solid lightgray; background-color: lightblue; border-radius: 3px; padding: 2px;">
                Current Item Price: $ <span id="priceValue">0.00</span>
            </div>

            

            <div class="row flex align-content-center justify-center">
                <?php $__currentLoopData = $door->doorNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-3 doorNameClass" style="border: 2px solid black; cursor: pointer"
                         id="doornameid-<?php echo e($n->id); ?>">
                        <img src="/storage/<?php echo e($n->image->image_path); ?>"
                             style="max-width: 255px ">
                        <p style="text-align: center" class="fw-bolder"><?php echo e($n->door_name_or_type); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($errors->has('door_name_type_id_selection')): ?>
                <div class="row flex m-3">
                    <div class="col-3">
                        <span class="" role="alert" style="color: red">
                            <strong>Please select a door type.</strong>
                        </span>
                    </div>
                </div>
            <?php endif; ?>

            

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row flex m-3">
                        <span class="" role="alert" style="color: red">
                                        <strong><?php echo e($error); ?></strong>
                                    </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: center" id="optSpecLabel">
                </div>
                <div class="col-4" id="optSpecSelect">
                </div>
            </div>

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Select Door Size
                </div>
                <div class="col-4">
                    <select name="door_size_select" id="doorSizeSelect" size="1"
                            style="width: 400px">
                        <option value="">Select a size...</option>
                        <?php $__currentLoopData = $door->doorMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"><?php echo e($m->width); ?> x <?php echo e($m->height); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" id="oldSize" value="<?php echo e(old('door_size_select')); ?>">
                </div>
            </div>

            <?php if(isset($door->category)): ?>
                <?php if(!str_contains($door->category->category_name, "Gliding")): ?>
                    

                    <div class="row flex m-3">
                        <div class="col-3" style="text-align: left">
                            Door Handling
                        </div>
                        <div class="col-4">
                            <select name="door_handling_select" id="doorHandlingSelect" size="1"
                                    style="width: 400px">
                                <option value="">Select a handling option...</option>
                                <?php $__currentLoopData = $door->doorHandlings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dh->id); ?>"><?php echo e($dh->handling); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="hidden" id="oldHandling" value="<?php echo e(old('door_handling_select')); ?>">
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            
            <?php if(isset($door->category)): ?>
                <?php if(!str_contains($door->category->category_name, "Gliding")): ?>
                    

                    <div class="row flex m-3">
                        <div class="col-3" style="text-align: left">
                            Door Frame
                        </div>
                        <div class="col-4">
                            <select name="door_frame_select" id="doorFrameSelect" size="1"
                                    style="width: 400px">
                                <option>Please select a frame type...</option>
                                <?php $__currentLoopData = $door->doorFrames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $df): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($df->id); ?>"><?php echo e($df->frame); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="hidden" id="oldFrame" value="<?php echo e(old('door_frame_select')); ?>">
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Color
                </div>
                <div class="col-4">
                    <select name="door_color_select" id="doorColorSelect" size="1"
                            style="width: 400px" disabled>
                        <option value="">Select a color option...</option>
                    </select>
                    <input type="hidden" id="oldColor" value="<?php echo e(old('door_color_select')); ?>">
                    <input type="hidden" id="panelCount" value="<?php echo e($door->panel_count??1); ?>">
                </div>
            </div>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Glass Grid (<?php echo e($door->panel_count??1); ?> Panel(s))
                </div>
                <div class="col-4">
                    <select name="glass_grid_select" id="glassGridSelect" size="1"
                            style="width: 400px" disabled>
                        <option value="-1">Please select a glass option...</option>
                    </select>
                    <input type="hidden" id="oldGlassGrid" value="<?php echo e(old('glass_grid_select')); ?>">
                </div>
            </div>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Glass Option
                </div>
                <div class="col-4" id="glassOptionSelectPlaceholder">
                    <select name="glass_option_select" id="glassOptionSelect" size="1"
                            style="width: 400px" disabled>
                        <option value="-1">Please select a glass option...</option>
                    </select>
                    <input type="hidden" id="oldGlassOption" value="<?php echo e(old('glass_option_select')); ?>">
                </div>
            </div>


            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Glass DEPTH Options
                </div>
                <div class="col-4" id="glassDepthSelectPlaceholder">
                    <select name="glass_depth_select" id="glassDepthSelect" size="1"
                            style="width: 400px" disabled>
                        <option>Please select glass depth...</option>
                    </select>
                    <input type="hidden" id="oldGlassDepth" value="<?php echo e(old('glass_depth_select')); ?>">
                </div>
            </div>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Handle Types
                </div>
                <div class="col-4" id="handleTypeSelectPlaceholder">
                    <select name="handle_type_select" id="handleTypeSelect" size="1"
                            style="width: 400px" disabled>
                        <option>Please select a handle...</option>
                    </select>
                    <input type="hidden" id="oldHandleType" value="<?php echo e(old('handle_type_select')); ?>">
                </div>
            </div>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Lock Set
                </div>
                <div class="col-4" id="lockSetSelectPlaceholder">
                    <select name="lock_set_select" id="lockSetSelect" size="1"
                            style="width: 400px" disabled>
                        <option>Please select a lock...</option>
                    </select>
                    <input type="hidden" id="oldLockset" value="<?php echo e(old('lock_set_select')); ?>">
                </div>
            </div>

            

            <div class="row flex m-3">
                <div class="col-3" style="text-align: left">
                    Frame Thickness
                </div>
                <div class="col-4" id="frameThicknessSelectPlaceholder">
                    <select name="frame_thickness_select" id="frameThicknessSelect" size="1"
                            style="width: 400px" disabled>
                        <option>Please select a thickness...</option>
                    </select>
                    <input type="hidden" id="oldThickness" value="<?php echo e(old('frame_thickness_select')); ?>">
                </div>
            </div>


            

            <?php $__currentLoopData = $door->customOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-none customOptionPlaceHolder" id="<?php echo e($customOption->id); ?>-<?php echo e($loop->index); ?>">
                    <input type="hidden" id="customOptionNamePlaceHolder-<?php echo e($loop->index); ?>"
                           value="<?php echo e($customOption->option_name); ?>">
                </div>
                <div class="row flex m-3">
                    <div class="col-3" style="text-align: left">
                        <?php echo e($customOption->option_name); ?>

                    </div>
                    <div class="col-4">
                        <select name="custom_option-<?php echo e($customOption->id); ?>"
                                id="customOptionSelect-<?php echo e($customOption->id); ?>-<?php echo e($loop->index); ?>"
                                style="width: 400px" disabled>
                            <option value="">Please select <?php echo e($customOption->option_name); ?>...</option>
                        </select>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

            <div class="row flex m-3" id="notesContainer">
                <div class="col-3" style="text-align: left">
                    Additional Notes
                </div>
                <div class="col-4" id="">
                                    <textarea class="form-control" style="width:300px;" rows="4"
                                              name="additional_notes"><?php echo e(old('additional_notes')); ?></textarea>
                </div>
            </div>

            

            <div class="cartButtonDiv" id="addItemToCartButton">
                <p style="">Add To Order</p>
            </div>
        </form>
    </div>

    

    <div class="d-none">
        <?php $__currentLoopData = $door->additionalOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addOn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($addOn->is_custom_option>0): ?>
                <div class="customOption addOn-<?php echo e($addOn->id); ?>">
                    <option value="<?php echo e($addOn->id); ?>" class=" addOnOption"
                            id="m-<?php echo e($addOn->is_custom_option); ?>-<?php echo e($addOn->door_measurement_id); ?>-<?php echo e($addOn->price); ?>"><?php echo e($addOn->name); ?></option>
                </div>

            <?php else: ?>
                <div class="addOn-<?php echo e($addOn->id); ?>">
                    <option value="<?php echo e($addOn->id); ?>" class="<?php echo e($addOn->group_name); ?> addOnOption"
                            id="m-<?php echo e($addOn->group_name); ?>-<?php echo e($addOn->door_measurement_id); ?>-<?php echo e($addOn->price); ?>"><?php echo e($addOn->name); ?></option>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="colors d-none">
            <?php $__currentLoopData = $door->doorMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $dm->doorFinishPrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doorFinishPrice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($doorFinishPrice->interior_color_id); ?>"
                        class="colorOption"
                        id="finish-<?php echo e($dm->id); ?>-<?php echo e($doorFinishPrice->id); ?>"><?php echo e($doorFinishPrice->interiorColor->color); ?>

                        - $<?php echo e($doorFinishPrice->price); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/shoppingcart/doorcart1.js')); ?>" defer></script>
        <script>
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/shoppingcart/doortuning.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create a Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">

        <div class="container" style="margin-top: 3px">
            <form class="row g-3" action="/p/doorflow/two" method="POST" enctype="multipart/form-data"
                  id="productDetailsForm">
                <input type="hidden" id="sizeCount" value="1" name="size_count">

                <?php if(!$door->isGliding()): ?>
                    <?php if($doorHandlingCount > 0): ?>
                        <input type="hidden" id="doorHandlingCount" value="<?php echo e($doorHandlingCount); ?>"
                               name="door_handling_count">
                    <?php else: ?>
                        <input type="hidden" id="doorHandlingCount" value="1" name="door_handling_count">
                    <?php endif; ?>
                    <?php if($doorFrameCount > 0): ?>
                        <input type="hidden" id="frameOptionCount" value="<?php echo e($doorFrameCount); ?>"
                               name="frame_option_count">
                    <?php else: ?>
                        <input type="hidden" id="frameOptionCount" value="1" name="frame_option_count">
                    <?php endif; ?>
                    <input type="hidden" id="isGliding" value="false">
                <?php else: ?>
                    <input type="hidden" id="isGliding" value="true">
                <?php endif; ?>

                <?php if($colorCount > 0): ?>
                    <input type="hidden" id="colorCount" value="<?php echo e($colorCount); ?>" name="color_count">
                <?php else: ?>
                    <input type="hidden" id="colorCount" value="1" name="color_count">
                <?php endif; ?>

                <input type="hidden" id="doorId" name="door_id" value="<?php echo e($door->id); ?>">

                <?php echo csrf_field(); ?>

                <div style="display: grid; grid-template-columns: 1fr 3fr">
                    <div class="left-1/3" style="margin-right: 2px; padding-right: 1px">
                        <div class="alert alert-success" role="alert">
                            <h2 class="alert-heading"><strong>Product - <?php echo e($door->name); ?></strong></h2>
                            <p>Add additional details about a product.</p>
                            <hr>

                        </div>
                    </div>
                    <div class="right-2/3">

                        <div>
                            <div id="errorContainer">
                                <?php if($errors): ?>
                                    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($error); ?></strong>
                        </span>
                                        <hr/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="container py-4">
                            <h5>Measurements</h5>
                            <div id="sizeContainer">
                                <div class="row  p-1 m-1 measurementRow">
                                    <div class="col" id="measurement-0">
                                        <label>Size Option W/H</label>
                                    </div>
                                    <div class="col">
                                        <input class="form-control dataField widthDatafield" type="text"
                                               name="width-0" id="width-0"
                                               placeholder="Width">
                                    </div>
                                    <div class="col">
                                        <input class="form-control dataField heightDatafield" type="text"
                                               name="height-0" id="height-0"
                                               placeholder="Height">
                                    </div>
                                    <div class="col-1"></div>
                                </div>
                            </div>
                            <div>
                                <div class="row p-1 m-1">
                                    <div class="col text-center">
                                        <button class="button-gci" id="addSizeButton">Add another size.</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="container py-4">
                            <h5>Finish/Colors (ie. Unstained Wood Grain Both Sides)</h5>
                            <div id="colorContainer">
                                <div class="row p-1 m-1 colorRow">
                                    <div class="col">
                                        <label>Finish/Color</label>
                                    </div>
                                    <div class="col">
                                        <input class="form-control dataField colorDatafield" type="text" name="color-0"
                                               placeholder="Finish/Color">
                                    </div>
                                    <div class="col-1"></div>
                                </div>
                            </div>
                            <div>
                                <div>
                                    <div class="row p-1 m-1">
                                        <div class="col text-center">
                                            <button class="button-gci" id="addColorButton">Add another Finish/Color.
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if(!$door->isGliding()): ?>
                            <div id="doorHandlingContainer">
                                <?php if($doorHandlingCount > 0): ?>
                                    <?php $__currentLoopData = $door->doorHandlings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="p-3 m-3" id="doorhandling-<?php echo e($loop->index); ?>">
                                            <label>Door Handling (ie. L Left Hand Opening)</label><br/>
                                            <input class="form-control  dataField" type="text" size="70"
                                                   name="doorhandling-<?php echo e($loop->index); ?>"
                                                   placeholder="Door Handling"
                                                   value="<?php echo e($h->handling); ?>">
                                            </td>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="p-3 m-3" id="doorhandling-0">
                                        <label>Door Handling (ie. L Left Hand Opening)</label><br/>
                                        <input class="form-control  dataField" type="text" size="70"
                                               name="doorhandling-0"
                                               placeholder="Door Handling">
                                        </td>
                                    </div>

                                <?php endif; ?>
                                <div class="col-lg p-3 m-3">
                                    <button class="button-gci" id="addDoorHandlingButton">Add another door handling.
                                    </button>
                                </div>
                            </div>
                            <div class="container">
                                <h5>Frames</h5>
                                <div id="frameContainer">
                                    <div class="col-lg p-3 m-3" id="frame-0">
                                        <label>Frame Options (ie. Knocked Down, Fully Assembled)</label><br/>
                                        <input class="form-control-sm dataField" size="70" type="text" name="frame-0"
                                               placeholder="Frame Option">
                                    </div>

                                    <div class="col-lg p-3 m-3">
                                        <button class="button-gci" id="addFrameOptionButton">Add another Frame Option.
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="row bottom-button-bar" role="alert">
        <div class="col">
            <button class="btn btn-primary" id="continueButton">Continue...</button>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/product/door/utility2.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/product/create/doorflow/steptwo.blade.php ENDPATH**/ ?>
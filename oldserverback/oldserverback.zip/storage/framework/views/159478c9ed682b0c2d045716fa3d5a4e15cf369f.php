<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Order Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-5 text-center">
        <h2>Order Details</h2>
        <p class="lead">Verify or update the address information below.</p>
        <div class="row flex m-3">

        </div>
    </div>
    <div class="container  mt-4" style="">
        <form action="/or/finalize" method="POST" id="cartItemForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="orderRequestId" name="order_request_id" value="<?php echo e($orderRequest->id); ?>">
            <div class="container">
                <div class="row">

                    <div class="col-md-8 mb-4">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="" role="alert" style="color: red">
                                        <strong><?php echo e($error); ?></strong>
                                    </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>

                    <div class="col-md-8 mb-4">
                        <div class="form-outline mb-4">
                            <label class="form-label" for="form7Example4">Expected Shipping date</label>
                            <input type="text"
                                   class="form-control<?php echo e($errors->has('expected_shipping_date') ? ' is-invalid': ''); ?>"
                                   id="expected_shipping_date"
                                   name="expected_shipping_date" required placeholder="MM-dd-YYYY" value="<?php echo e(date('m-d-Y' , strtotime( '+20 days'))); ?>"
                                   autocomplete="expected_shipping_date">

                        </div>
                    </div>

                    <div class="col-md-8 mb-4">
                        <div class="card mb-4">
                            <div class="card-header py-3">
                                <h5 class="mb-0">Shipping Address</h5>
                            </div>
                            <div class="card-body">

                                <div class="form-outline mb-4">
                                    <label class="form-label" for="form7Example4">Address</label>
                                    <input type="text"
                                           class="form-control<?php echo e($errors->has('address1') ? ' is-invalid': ''); ?>"
                                           id="address1"
                                           name="address1" value="<?php echo e(old('address1')); ?>"
                                           autocomplete="address1">

                                </div>

                                <div class="row mb-4">
                                    <div class="col">
                                        <div class="form-outline">
                                            <label class="form-label" for="form7Example1">City</label>
                                            <input type="text"
                                                   class="form-control<?php echo e($errors->has('city') ? ' is-invalid': ''); ?>"
                                                   id="city"
                                                   name="city"  value="<?php echo e(old('city')); ?>"
                                                   autocomplete="city">

                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-outline">
                                            <label class="form-label" for="form7Example2">State</label>

                                                <select id="state" name="state" class="form-control">
                                                    <?php $__currentLoopData = $usStates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>


                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-outline">
                                            <label class="form-label" for="form7Example2">Zip</label>

                                            <input type="text"
                                                   class="form-control<?php echo e($errors->has('zipcode') ? ' is-invalid': ''); ?>"
                                                   id="zipcode" value="<?php echo e(old('zipcode')); ?>"
                                                   name="zipcode"
                                                   autocomplete="zipcode">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-outline mb-4">
                                    <label class="form-label" for="form7Example7">Order Notes</label>
                                    <textarea class="form-control" id="addInfo" name="additionalInformation" rows="4"><?php echo e(old('additionalInformation')); ?></textarea>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card mb-4">
                            <div class="card-header py-3">
                                <h5 class="mb-0">Summary</h5>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 pb-0">
                                        Products
                                        <span>$ <?php echo e($orderRequest->total); ?></span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                        Shipping
                                        <span>$ 0.00</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3">
                                        <div>
                                            <strong>Total amount</strong>
                                            <strong>
                                                <p class="mb-0"></p>
                                            </strong>
                                        </div>
                                        <span><strong>$ <?php echo e(sprintf('%0.02f', $orderRequest->total)); ?></strong></span>
                                    </li>
                                </ul>

                                <div class="p-6 bg-white border-b border-gray-200  ">
                                    <button class="btn btn-primary">
                                        Send Request
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>


            <?php $__env->startSection('scripts'); ?>
                <script src="<?php echo e(asset('js/orderrequest/finalize.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/orderrequest/steptwo.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Categories')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container py-4">
        <div class="card">
            <h5 class="card-header">Categories</h5>
            <div class="card-body">
                <?php if(isset($categories)): ?>
                    <table class="table table-striped" id="userTable" style="width: 100%">
                        <thead>
                        <th></th>
                        <th>Category Name</th>
                        <th>Notes</th>
                        <th>Products in Category</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php /* echo  '<pre>'; var_dump($category); echo  '</pre>';die;*/ ?>

                            <tr class="categoryRow" id="categoryRow-<?php echo e($category->id); ?>" style="cursor: pointer ">
                                <td class="d-none"><?php echo e($category->id); ?></td>
                                <td class="alert-info delete"
                                    style="text-align: center;cursor:pointer;background: red"
                                    id="deleteCategory-<?php echo e($category->id); ?>-<?php echo e($category->category_name); ?>"
                                    href="/c/delete/<?php echo e($category->id); ?>">
                                        <span>
                                            <p id="deleteCategory-<?php echo e($category->id); ?>-<?php echo e($category->category_name); ?>"
                                               class="deleteCategory">X</p>
                                        </span>
                                </td>
                                <td><?php echo e($category->category_name); ?></td>
                                <td><?php echo e($category->category_note); ?></td>






                                <td><?php echo e($category->products_sum); ?></td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            <div class="align-content-end " style="margin-right: 20px; text-align: right">
                <a href="<?php echo e(route('ccreate')); ?>">
                    <button class="btn btn-primary mb-3">Create a new category</button>
                </a>
            </div>
        </div>
    </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/category/view.js')); ?>" defer></script>
        <script>
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/category/view.blade.php ENDPATH**/ ?>
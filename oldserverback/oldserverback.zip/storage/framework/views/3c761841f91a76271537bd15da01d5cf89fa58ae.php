<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create a Product')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container" style="margin-top: 3px">
        <form class="row g-3" action="/p/doorflow/three" method="POST" enctype="multipart/form-data"
              id="productPricesForm">
            <input type="hidden" value="<?php echo e($door->id); ?>" name="door_id" id="doorId">
            <?php echo csrf_field(); ?>

            <div style="display: grid; grid-template-columns: 1fr 3fr">
                <div class="left-1/3" style="margin-right: 2px; padding-right: 1px">
                    <div class="alert alert-success" role="alert">
                        <h2 class="alert-heading"><strong>Product</strong></h2>
                        <p>Set prices for sizes / options.</p>
                        <hr>

                    </div>
                </div>
                <div class="right-2/3">
                    <div class="d-none"> <?php echo e($tabindex = 0); ?></div>
                    <?php $__currentLoopData = $door->interiorColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $door->doorMeasurements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <input type="hidden" name="price-<?php echo e($color->id); ?><?php echo e($m->id); ?>">
                                <div class="col-1 p-3 m-3">
                                    <?php echo e($color->color); ?>:
                                </div>
                                <div class="col-2 p-3 m-3">
                                    <?php echo e($m->width); ?> x <?php echo e($m->height); ?>

                                </div>
                                <div class="col-2 p-3 m-3">
                                    <label for="isNA">NA?</label>
                                    <input type="checkbox" class="sizePriceNA" name="is_na-<?php echo e($color->id); ?><?php echo e($m->id); ?>"
                                           id="isNA-<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>" tabindex="-1">
                                </div>
                                <div class="col-1 p-3 m-3">
                                    <input type="number" class="sizePrice dataField" placeholder="price"
                                           id="sizePrice-<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>"
                                           name="sizePrice-<?php echo e($color->id); ?><?php echo e($m->id); ?>" value="0"
                                    >
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </form>
    </div>

    <div class="row bottom-button-bar" role="alert">
            <div class="col">
                <button class="btn btn-primary" id="continueButton">Continue...</button>
            </div>
        </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/product/door/utility3.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/product/create/doorflow/stepthree.blade.php ENDPATH**/ ?>
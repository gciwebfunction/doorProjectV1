<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Order Confirmation')); ?> <?php echo e($or->id); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-5 text-center">
        <h2>Order Conversion</h2>
        <p class="lead">Verify the order below. All items are editable for a final check before creating the official
            order.</p>
    </div>
    <div class="container  mt-4" style="">
        <form action="/or/confirmstepone/<?php echo e($or->id); ?>" method="POST"
              id="cartItemForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="orderRequestId" name="order_request_id" value="<?php echo e($or->id); ?>">
            <input type="hidden" id="orderItemCount" name="item_count" value="<?php echo e($item_count); ?>">
            <div class="row g-1">

                <?php $__currentLoopData = $or->doorItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doorItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-7 col-lg-8" style="float: left">
                        <h4 class="mb-3">Item Number #<?php echo e($loop->index+1); ?></h4>
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <label for="doorName-<?php echo e($loop->index); ?>" class="form-label">Door name</label>
                                <input type="text" class="form-control" id="doorName-<?php echo e($loop->index); ?>" placeholder=""
                                       name="door_name-<?php echo e($loop->index); ?>"
                                       value="<?php echo e($doorItem->door_name); ?>"
                                       required>
                                <div class="invalid-feedback">
                                    Valid name is required.
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <label for="categoryName-<?php echo e($loop->index); ?>" class="form-label">Category Name</label>
                                <input type="text" class="form-control"
                                       id="categoryName-<?php echo e($loop->index); ?>"
                                       name="category_name-<?php echo e($loop->index); ?>" value="<?php echo e($doorItem->category_name); ?>"
                                       required>
                                <div class="invalid-feedback">
                                    Category name is required.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="doorTypePrettyName-<?php echo e($loop->index); ?>" class="form-label">Door Type</label>
                                <input type="text" class="form-control"
                                       id="doorTypePrettyName-<?php echo e($loop->index); ?>"
                                       name="door_type_pretty_name-<?php echo e($loop->index); ?>"
                                       value="<?php echo e($doorItem->door_type_pretty_name); ?>"
                                       required>
                                <div class="invalid-feedback">
                                    Door type is required.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="quantity-<?php echo e($loop->index); ?>" class="form-label">Quantity</label>
                                <input type="number" class="form-control"
                                       id="quantity-<?php echo e($loop->index); ?>"
                                       name="quantity-<?php echo e($loop->index); ?>"
                                       value="<?php echo e($doorItem->quantity); ?>">
                                <div class="invalid-feedback">
                                    Please enter a valid quantity.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="address" class="form-label">Item Price</label>
                                <input type="number" class="form-control" id="price-<?php echo e($loop->index); ?>"
                                       name="price-<?php echo e($loop->index); ?>"
                                       value="<?php echo e($doorItem->price); ?>">
                                <div class="invalid-feedback">
                                    Please enter a valid price.
                                </div>
                            </div>


                            <div class="col-12">
                                <label for="address" class="form-label">Calculated Discount</label>
                                <input type="text" readonly class="form-control"
                                       name="calculated_discount-<?php echo e($loop->index); ?>"
                                       value="<?php echo e($doorItem->calculated_discount); ?>">
                                <div class="invalid-feedback">

                                </div>
                            </div>


                            <hr class="my-4">

                            <?php $__currentLoopData = $doorItem->doorItemModifiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modifier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($modifier->door_modifier_key == 'SIZE'): ?>
                                    <div class="col-sm-6">
                                        <label class="form-label">Width</label>
                                        <input type="text" class="form-control" name="width-<?php echo e($loop->parent->index); ?>"
                                               value="<?php echo e(explode(" ", $modifier->door_modifier_value)[0]); ?>"
                                               required>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label">Height</label>
                                        <input type="text" class="form-control"
                                               name="width-<?php echo e($loop->parent->index); ?>"
                                               value="<?php echo e(explode(" ", $modifier->door_modifier_value)[1]); ?>"
                                               required>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php $__currentLoopData = $doorItem->doorItemModifiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modifier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($modifier->door_modifier_key != 'SIZE'): ?>
                                    <div class="col-12">
                                        <label class="form-label"><?php echo e($modifier->door_modifier_key); ?></label>
                                        <input type="text" class="form-control" name="<?php echo e($modifier->door_modifier_key); ?>-<?php echo e($loop->parent->index); ?>"
                                               value="<?php echo e($modifier->door_modifier_value); ?>">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                    <div class="container py-3"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-5 col-lg-4" style=" position: fixed; right: 20px; top: 320px;">
                    <h4 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-primary">Information</span>
                        <span class="badge bg-primary rounded-pill"><?php echo e($item_count); ?></span>
                    </h4>
                    <ul class="list-group mb-3">
                        <li class="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 class="my-0">Order Request#</h6>
                            </div>
                            <span class="text-muted"><?php echo e($or->id); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 class="my-0">Owner</h6>
                                <small class="text-muted">User: <?php echo e($or->user_id); ?></small>
                            </div>
                            <span class="text-muted"><?php echo e($or_owner); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 class="my-0">Distributor</h6>
                                <small class="text-muted">Dist-Id <?php echo e($or->distributor_id?? ''); ?></small>
                            </div>
                            <span class="text-muted"><?php echo e($or_dist?$or_dist->email:''); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 class="my-0">Expected Shipping Date</h6>
                                <small class="text-muted"></small>
                            </div>
                            <span class="text-muted"><?php echo e($or->expected_shipping_date?? ''); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between bg-light">
                            <div class="text-success">
                                <h6 class="my-0">Order Discount</h6>
                                <small>0%</small>
                            </div>
                            <span class="text-success">$0.00</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Total (USD)</span>
                            <strong>$ <?php echo e($or->total); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <button type="submit" value="Convert Order">Convert Order</button>
                        </li>
                    </ul>


                </div>
            </div>
        </form>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/order/confirm1.js')); ?>" defer></script>
        <script>
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/order/confirmation/stepone.blade.php ENDPATH**/ ?>
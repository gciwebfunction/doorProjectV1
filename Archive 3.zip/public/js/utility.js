/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*********************************!*\
  !*** ./resources/js/utility.js ***!
  \*********************************/
function tableRowClick(url, id) {
  window.location = url + "/" + id;
} //
// const userTable = document.getElementById('userTable');
// const userTableRows = document.getElementsByTagName('tr');
//
// if (userTableRows) {
//     userTableRows.addEventListener('click', function () {
//         const tds = this.getElementsByTagName('td');
//         const userId = tds[0].innerText;
//
//         location.href="/u/"+userId;
//     });
// }
/******/ })()
;
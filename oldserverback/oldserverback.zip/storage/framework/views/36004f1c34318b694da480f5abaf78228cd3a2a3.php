<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('User Management')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <h5 class="text-center">User Management</h5>


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>


        <table class="table table-striped" id="userTable" style="width: 100%">
            <thead>
            <th>Name</th>
            <th>Email</th>
            <th>User Type</th>
            <th class="text-center">Disabled</th>
            </thead>
            <?php $__currentLoopData = $detailedusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detaileduser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="" style="cursor: pointer">
                    <td class="d-none"><?php echo e($detaileduser->id); ?></td>
                    <td><?php echo e($detaileduser->name); ?></td>
                    <td><?php echo e($detaileduser->email); ?></td>

                    <?php if($detaileduser->usertype == 'manufacturer'): ?>
                        <td class="table-cell">
                            <span style="color: red"><?php echo e($detaileduser->usertype); ?></span>
                        </td>
                    <?php else: ?>
                        <td>
                            <?php echo e($detaileduser->usertype); ?>

                        </td>
                    <?php endif; ?>

                    <?php if($detaileduser->disabled == 1): ?>
                        <td class="table-cell disabled-indicator text-center">
                            <span style="color: red">DISABLED</span>
                        </td>
                    <?php else: ?>
                        <td class="table-cell disabled-indicator text-center">
                            <span style="color: green;">ENABLED</span>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>

        <?php if(auth()->check() && auth()->user()->hasPermission('c_user')){?>
        <div class="row bottom-button-bar" role="alert">
            <div class="col">
                    <button class="btn btn-primary" onclick="window.location='<?php echo e(route('ucreate')); ?>'">
                        Create a new user
                    </button>
                </div>
            </div>
        </div>
        <?php } ?>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/user/view.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/user/view.blade.php ENDPATH**/ ?>
window.onload = function () {
    init();
}

window.deleteOrderRequest = function (id) {
    window.location = "/or/delete/" + id;
}

window.deleteOrder = function (id) {
    window.location = "/o/delete/" + id;
}

function init() {
    $('#orderRequestTable').DataTable();
    $('#orderTable').DataTable();
}

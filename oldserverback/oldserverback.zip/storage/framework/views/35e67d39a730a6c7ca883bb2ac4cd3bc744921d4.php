<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <form action="/or/<?php echo e($shoppingCart->id??''); ?>" method="POST" id="cartForm">
        <div class="container" style="margin-top: 3px;;min-width: 900px">
            <div style="">
                <div class="left-1/3">
                    <div class="alert alert-success" role="alert">
                        <h2 class="alert-heading"><strong>Order Details</strong></h2>
                        <p>View current products prior to submitting the order.</p>
                        <hr/>
                    </div>
                </div>
                <div class="right-2/3">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="shoppingCartId" name="shopping_cart_id"
                           value="<?php echo e($shoppingCart->id ?? ''); ?>">
                </div>
            </div>
            <div id="message" class="text-center">

            </div>
            <div id="centerFloatDiv" class="d-none">
                <div class="divFloat" id="divFloat" style="text-align: center"></div>
            </div>
            <div class="" id="cartContents" style="width:95%; padding:1px;margin:1px;min-width: 800px">
                <table class="display" id="cartTable">
                    <thead>
                    <tr>
                        <th>Quantity</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Size</th>
                        <th>Frame</th>
                        <th>Color</th>
                        <th>Grid</th>
                        <th>Handle</th>
                        <th>Lock</th>
                        <th>Price</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($shoppingCart ?? ''  && $cartItemCount > 0): ?>
                        <?php $__currentLoopData = $doorViewItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="itemRow1-<?php echo e($item->getId()); ?>">
                                <td><?php echo e($item->getQuantity()); ?></td>
                                <td><?php echo e($item->getName()); ?></td>
                                <td><?php echo e($item->getCategoryName()); ?></td>
                                <td><?php echo e($item->getSize()); ?></td>
                                <td><?php echo e($item->getFrame()); ?></td>
                                <td><?php echo e($item->getColor()); ?></td>
                                <td><?php echo e($item->getGrid()); ?></td>
                                <td><?php echo e($item->getHandle()); ?></td>
                                <td><?php echo e($item->getLock()); ?></td>
                                <td>$<?php echo e(sprintf('%01.2f',$item->getPrice())); ?></td>
                                <td class="delete alert-danger col-1 m-1 p-1"
                                    style="background-color: red; text-align: center;width: 20px; padding-right: 1px; height: 20px; border-radius: 2px"
                                    id="item-<?php echo e($item->getId()); ?>">
                                    X
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr id="nothingInYourCartContainer">
                            <td colspan="17">
                                Nothing in your cart!
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>

                <div class="container py-4 mb-5">
                    <h4 class="text-center">Other Products</h4>
                </div>

                <table class="display" id="otherCartTable">
                    <thead>
                    <tr>
                        <th>Quantity</th>
                        <th>Product Name</th>
                        <th>Option</th>
                        <th>Size</th>
                        <th>Color</th>
                        <th>Price</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($shoppingCart->cartItems)): ?>
                        <?php $__currentLoopData = $shoppingCart->cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="cartItemRow1-<?php echo e($item->id); ?>">
                                <td><?php echo e($item->quantity); ?></td>
                                <td><?php echo e($item->product_name); ?></td>
                                <td><?php echo e($item->option_name); ?></td>
                                <td><?php echo e($item->product_size); ?></td>
                                <td><?php echo e($item->product_color); ?></td>
                                <td>$<?php echo e(sprintf('%0.2f',$item->product_unit_price)); ?></td>
                                <td class="delete alert-danger col-1 m-1 p-1"
                                    style="background-color: red; text-align: center;width: 20px; padding-right: 1px; height: 20px; border-radius: 2px"
                                    id="cartItem-<?php echo e($item->id); ?>">
                                    X
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <div class="row flex p-1 m-1">
                    <div class="col-12">
                        <hr/>
                    </div>
                </div>
                <div class="row flex p-1 m-1">
                    <div class="col-4">
                    </div>
                    <div class="col-4">
                        Order Subtotal
                    </div>
                    <div class="col-4 currSign" id="orderSubtotalContainer">
                        <?php echo e($cartSubtotal ?? '0.00'); ?>

                    </div>
                </div>
                <div class="row flex p-1 m-1">
                    <div class="col-4">
                    </div>
                    <div class="col-4">
                        Order Discounts
                    </div>
                    <div class="col-4 currSign" id="orderDiscountContainer">
                        <?php echo e($orderDiscount ?? '0.00'); ?>

                    </div>
                </div>
                <div class="row flex p-1 m-1">
                    <div class="col-4">
                    </div>
                    <div class="col-4">
                        Order Total
                    </div>

                    <div class="col-4 currSign" id="orderTotalContainer">
                        <?php echo e($orderTotal ?? '$ 0.00'); ?>

                    </div>
                </div>
            </div>
            <div class="alert alert-warning" role="alert" style="width:80%; margin: 5px auto 0;">
                <div class="row">
                    <div class="col-sm" style="text-align: center;">
                        <button type="button"  id="clearCart" class="ml-10 button-gci">
                            <span aria-hidden="true">Clear Cart</span>
                        </button>
                    </div>
                    <div class="col-sm" style="text-align: center;">
                        <button type="button"  id="goBackToCatalogButton"
                                class="ml-10 button-gci">
                            <span aria-hidden="true">Keep Shopping</span>
                        </button>
                    </div>
                    <div class="col-sm" style="text-align: center;">
                        <button type="button"  id="submitOrderButton" class="ml-10 button-gci">
                            <span aria-hidden="true">Submit Order Request...</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/shoppingcart/cartviewdoor.js')); ?>" defer></script>
        <script>
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/shoppingcart/viewdoor.blade.php ENDPATH**/ ?>
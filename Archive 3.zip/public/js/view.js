/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./resources/js/product/view.js ***!
  \**************************************/
$('#productTable tr').click(function () {
  alert($(this).first().text());
});
/******/ })()
;
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>GCI Software</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="/css/bootstrap.css" rel="stylesheet">
    <!-- Styles -->
    <style>
        /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
        html {
            line-height: 1.15;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        a {
            background-color: transparent
        }

        [hidden] {
            display: none
        }

        html {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Noto Sans, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            line-height: 1.5
        }

        *, :after, :before {
            box-sizing: border-box;
            border: 0 solid #e2e8f0
        }

        a {
            color: inherit;
            text-decoration: inherit
        }

        svg, video {
            display: block;
            vertical-align: middle
        }

        video {
            max-width: 100%;
            height: auto
        }

        .bg-white {
            --bg-opacity: 1;
            background-color: #fff;
            background-color: rgba(255, 255, 255, var(--bg-opacity))
        }

        .bg-gray-100 {
            --bg-opacity: 1;
            background-color: #f7fafc;
            background-color: rgba(247, 250, 252, var(--bg-opacity))
        }

        .border-gray-200 {
            --border-opacity: 1;
            border-color: #edf2f7;
            border-color: rgba(237, 242, 247, var(--border-opacity))
        }

        .border-t {
            border-top-width: 1px
        }

        .flex {
            display: flex
        }

        .grid {
            display: grid
        }

        .hidden {
            display: none
        }

        .items-center {
            align-items: center
        }

        .justify-center {
            justify-content: center
        }

        .font-semibold {
            font-weight: 600
        }

        .h-5 {
            height: 1.25rem
        }

        .h-8 {
            height: 2rem
        }

        .h-16 {
            height: 4rem
        }

        .text-sm {
            font-size: .875rem
        }

        .text-lg {
            font-size: 1.125rem
        }

        .leading-7 {
            line-height: 1.75rem
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto
        }

        .ml-1 {
            margin-left: .25rem
        }

        .mt-2 {
            margin-top: .5rem
        }

        .mr-2 {
            margin-right: .5rem
        }

        .ml-2 {
            margin-left: .5rem
        }

        .mt-4 {
            margin-top: 1rem
        }

        .ml-4 {
            margin-left: 1rem
        }

        .mt-8 {
            margin-top: 2rem
        }

        .ml-12 {
            margin-left: 3rem
        }

        .-mt-px {
            margin-top: -1px
        }

        .max-w-6xl {
            max-width: 72rem
        }

        .min-h-screen {
            min-height: 100vh
        }

        .overflow-hidden {
            overflow: hidden
        }

        .p-6 {
            padding: 1.5rem
        }

        .py-4 {
            padding-top: 1rem;
            padding-bottom: 1rem
        }

        .px-6 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }

        .pt-8 {
            padding-top: 2rem
        }

        .fixed {
            position: fixed
        }

        .relative {
            position: relative
        }

        .top-0 {
            top: 0
        }

        .right-0 {
            right: 0
        }

        .shadow {
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px 0 rgba(0, 0, 0, .06)
        }

        .text-center {
            text-align: center
        }

        .text-gray-200 {
            --text-opacity: 1;
            color: #edf2f7;
            color: rgba(237, 242, 247, var(--text-opacity))
        }

        .text-gray-300 {
            --text-opacity: 1;
            color: #e2e8f0;
            color: rgba(226, 232, 240, var(--text-opacity))
        }

        .text-gray-400 {
            --text-opacity: 1;
            color: #cbd5e0;
            color: rgba(203, 213, 224, var(--text-opacity))
        }

        .text-gray-500 {
            --text-opacity: 1;
            color: #a0aec0;
            color: rgba(160, 174, 192, var(--text-opacity))
        }

        .text-gray-600 {
            --text-opacity: 1;
            color: #718096;
            color: rgba(113, 128, 150, var(--text-opacity))
        }

        .text-gray-700 {
            --text-opacity: 1;
            color: #4a5568;
            color: rgba(74, 85, 104, var(--text-opacity))
        }

        .text-gray-900 {
            --text-opacity: 1;
            color: #1a202c;
            color: rgba(26, 32, 44, var(--text-opacity))
        }

        .underline {
            text-decoration: underline
        }

        .antialiased {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .w-5 {
            width: 1.25rem
        }

        .w-8 {
            width: 2rem
        }

        .w-auto {
            width: auto
        }

        .grid-cols-1 {
            grid-template-columns:repeat(1, minmax(0, 1fr))
        }

        @media (min-width: 640px) {
            .sm\:rounded-lg {
                border-radius: .5rem
            }

            .sm\:block {
                display: block
            }

            .sm\:items-center {
                align-items: center
            }

            .sm\:justify-start {
                justify-content: flex-start
            }

            .sm\:justify-between {
                justify-content: space-between
            }

            .sm\:h-20 {
                height: 5rem
            }

            .sm\:ml-0 {
                margin-left: 0
            }

            .sm\:px-6 {
                padding-left: 1.5rem;
                padding-right: 1.5rem
            }

            .sm\:pt-0 {
                padding-top: 0
            }

            .sm\:text-left {
                text-align: left
            }

            .sm\:text-right {
                text-align: right
            }
        }

        @media (min-width: 768px) {
            .md\:border-t-0 {
                border-top-width: 0
            }

            .md\:border-l {
                border-left-width: 1px
            }

            .md\:grid-cols-2 {
                grid-template-columns:repeat(2, minmax(0, 1fr))
            }
        }

        @media (min-width: 1024px) {
            .lg\:px-8 {
                padding-left: 2rem;
                padding-right: 2rem
            }
        }

        @media (prefers-color-scheme: dark) {
            .dark\:bg-gray-800 {
                --bg-opacity: 1;
                background-color: #2d3748;
                background-color: rgba(45, 55, 72, var(--bg-opacity))
            }

            .dark\:bg-gray-900 {
                --bg-opacity: 1;
                background-color: #1a202c;
                background-color: rgba(26, 32, 44, var(--bg-opacity))
            }

            .dark\:border-gray-700 {
                --border-opacity: 1;
                border-color: #4a5568;
                border-color: rgba(74, 85, 104, var(--border-opacity))
            }

            .dark\:text-white {
                --text-opacity: 1;
                color: #fff;
                color: rgba(255, 255, 255, var(--text-opacity))
            }

            .dark\:text-gray-400 {
                --text-opacity: 1;
                color: #cbd5e0;
                color: rgba(203, 213, 224, var(--text-opacity))
            }

            .dark\:text-gray-500 {
                --tw-text-opacity: 1;
                color: #6b7280;
                color: rgba(107, 114, 128, var(--tw-text-opacity))
            }
        }
    </style>

    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }

        .b-example-divider {
            height: 3rem;
            background-color: rgba(0, 0, 0, .1);
            border: solid rgba(0, 0, 0, .15);
            border-width: 1px 0;
            box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
        }

        @media (min-width: 992px) {
            .rounded-lg-3 {
                border-radius: .3rem;
            }
        }
    </style>

    <script type="application/javascript" src="/js/bootstrap.js"></script>
</head>
<body class="antialiased bg-gray-100 dark:bg-gray-900 ">
<?php if(Route::has('login')): ?>
    <div class="container sticky-top bg-gray-100" style="min-width: 900px">
        <header
            class="d-flex flex-wrap align-items-center justify-content-center text-right py-3 mb-4 bg">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 dark:text-gray-500 ">Dashboard</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 ">Log in</a>
            <?php endif; ?>
        </header>
    </div>
<?php endif; ?>

<div class="p-4 p-md-5 mb-4 text-white rounded bg-dark mt-4">
    <div class="col-md-6 px-0">
        <h1 class="display-3 ">GCI</h1>
        <h1 class="display-4 ">The Online Store</h1>
        <p class="lead my-3">Our team is working to deliver a high-quality, efficient, and productive online catalog,
            facilitating end users with the ability to source their construction needs.</p>
    </div>

    <button type="button" class="btn btn-secondary btn-lg px-4 text-gray-500 hover:text-gray-800"
            onclick="event.preventDefault();
            window.location = '/dashboard';">Order
    </button>
</div>

<div class="row mb-2">
    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-primary">Featured Product</strong>
                <h3 class="mb-0">Hinged Units</h3>
                <p class="card-text mb-auto">We like to be as straightforward as possible and make the Hinged Units
                    remodeling experience easy and simple!</p>
                <a href="/dashboard" class="stretched-link">Sign in to order...</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="/img/hinged_units.jpeg" class="img-fluid border rounded-3 shadow-lg mb-3"
                     alt="Hinged Door Units" width="238" height="200" loading="lazy">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-primary">Featured Product</strong>
                <h3 class="mb-0">Gliding Units</h3>
                <p class="card-text mb-auto">We like to be as straightforward as possible and make the Hinged Units
                    remodeling experience easy and simple!</p>
                <a href="/dashboard" class="stretched-link">Sign in to order...</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="/img/gliding_units.jpeg" class="img-fluid border rounded-3 shadow-lg mb-3"
                     alt="Hinged Door Units" width="238" height="200" loading="lazy">
            </div>
        </div>
    </div>
</div>

<div class="row mb-2">
    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-primary">Featured Product</strong>
                <h3 class="mb-0">Folding Units</h3>
                <p class="card-text mb-auto">We like to be as straightforward as possible and make the Hinged Units
                    remodeling experience easy and simple!</p>
                <a href="/dashboard" class="stretched-link">Sign in to order...</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="/img/folding_units.jpeg" class="img-fluid border rounded-3 shadow-lg mb-3"
                     alt="Hinged Door Units" width="238" height="200" loading="lazy">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-primary">Featured Product</strong>
                <h3 class="mb-0">Bypass Gliding Units</h3>
                <p class="card-text mb-auto">We like to be as straightforward as possible and make the Hinged Units
                    remodeling experience easy and simple!</p>
                <a href="/dashboard" class="stretched-link">Sign in to order...</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="/img/bypass_gliding_units.jpeg" class="img-fluid border rounded-3 shadow-lg mb-3"
                     alt="Hinged Door Units" width="238" height="200" loading="lazy">
            </div>
        </div>
    </div>
</div>


<div class="row mb-2">
    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-primary">Featured Product</strong>
                <h3 class="mb-0">Vented Sidelights Units</h3>
                <p class="card-text mb-auto">We like to be as straightforward as possible and make the Hinged Units
                    remodeling experience easy and simple!</p>
                <a href="/dashboard" class="stretched-link">Sign in to order...</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="/img/vented_sidelights_units.jpeg" class="img-fluid border rounded-3 shadow-lg mb-3"
                     alt="Hinged Door Units" width="238" height="200" loading="lazy">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <strong class="d-inline-block mb-2 text-primary">Featured Product</strong>
                <h3 class="mb-0">Parts</h3>
                <p class="card-text mb-auto">We also offer only parts for the doors!</p>
                <a href="/dashboard" class="stretched-link">Sign in to order...</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="/img/parts.jpeg" class="img-fluid border rounded-3 shadow-lg mb-3" alt="Hinged Door Units"
                     width="238" height="200" loading="lazy">
            </div>
        </div>
    </div>
</div>


</body>
</html>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/welcome.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product\ImageDetails;
use Illuminate\Support\Facades\Auth;
use Junges\ACL\Exceptions\UnauthorizedException;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function create()
    {
        return view('category.create');
    }

    public function show($id)
    {
        $user = Auth::user();
        if ($user->hasPermission('r_category')) {
            return view('category.viewone', ['category' => Category::findOrFail($id)]);
        }

        $exception = UnauthorizedException::forPermissions(['r_category']);

        throw UnauthorizedException::forPermissions(['r_category']);
    }

    public function store()
    {
        $user = Auth::user();
        if (!$user->hasPermission('c_category')) {
            throw UnauthorizedException::forPermissions(['u_category', 'r_category']);
        }
        $image = '';
        $uploaded = request('category_image');

        $data = request()->validate([
            'category_name' => 'required|unique:categories',
            'category_type' => 'required',
            'category_note' => '',
        ]);

        $note = '';
        if (isset($data['category_note']) || !$data['category_note'] == '') {
            $note = $data['category_note'];
        }

        $imageId = 1;

        if (isset($data['image_id'])) {
            $data = $data['image_id'];
        }

        $category = Category::create([
            'category_name' => $data['category_name'],
            'category_note' => $note,
            'type' => $data['category_type'],
            'image_id' => $imageId,
        ]);

        if ($uploaded) {
            $image = ControllerUtilities::storeImage($uploaded, $category->id);
        }
        if ($image == '') {
            $image = ImageDetails::findOrFail(1);
        }

        return view('category.view', [
            'categories' => Category::all()
        ]);

    }

    public function update()
    {
        $user = Auth::user();
        if (!$user->hasPermission('c_category')) {
            throw UnauthorizedException::forPermissions(['u_category', 'r_category']);
        }
        $image = '';
        $uploaded = request('category_image');

        $data = request()->validate([
            'category_name' => 'required',
            'category_note' => '',
            'category_id' => 'required',
        ]);

        $category = Category::findOrFail($data['category_id']);

        if ($uploaded) {
            $image = ControllerUtilities::storeImageForCategory($uploaded, $category->id);
        }

        if ($category->image_id < 2) {
            if ($image == '') {
                $image = ImageDetails::findOrFail(1);
            }
        }

        $note = '';

        if (isset($data['category_note'])) {
            $note = $data['category_note'];
        }

        $category->update([
            'category_name' => $data['category_name'],
            'category_note' => $note,
            'image_id' => $image ? $image->id : $category->image_id,
        ]);


        return redirect()->route('cview',
            ['categories' => \App\Models\Category::all()]);
    }


    /**
     * Delete a category.
     *
     * @param $categoryId - the Category to delete.
     * @return void
     */
    public function deleteCategory($categoryId)
    {
        $category = Category::findOrFail($categoryId);

        $category->delete();
    }
}

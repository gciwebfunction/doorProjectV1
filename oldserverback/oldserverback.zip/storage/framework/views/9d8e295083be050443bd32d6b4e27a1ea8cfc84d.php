<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Product Management')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container py-4">
        <div class="text-end " style="margin-right: 20px; text-align: right; position: fixed; right: 50px; top: 120px; z-index: 1000000">
            <a href="<?php echo e(route('pcreatedoorflowstepone')); ?>">
                <button class="btn btn-primary mb-3">Add New Product
                </button>
            </a>
        </div>
        <div class="card">
            <h5 class="card-header">Product List</h5>
            <div class="card-body">

                <div id="message" class="text-center">
                </div>

                <div id="centerFloatDiv" class="d-none">
                    <div class="divFloat" id="divFloat" style="text-align: center"></div>
                </div>

                <input type="hidden" value="" id="deleteLocation">

                <?php if(isset($doors)): ?>
                    <table class="table table-striped" id="productTable" style="width: 100%">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Product</th>
                            <th>Type</th>
                            <th>Names</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $doors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="" style="cursor: pointer" id="rowProductId-<?php echo e($product->id); ?>">
                                <td class="d-none"><?php echo e($product->id); ?></td>
                                <td class="alert-danger delete">
                                    <div data-bs-toggle="modal" data-bs-target="#deleteProduct<?php echo e($product->id); ?>"
                                         style="text-align: center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#FF0000"
                                             class="bi bi-x" viewBox="0 0 16 16">
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                        </svg>
                                    </div>
                                    <div class="modal" id="deleteProduct<?php echo e($product->id); ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Delete Order Request</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete product: <?php echo e($product->name); ?>?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">
                                                        Cancel
                                                    </button>
                                                    <button type="button" class="btn btn-primary"
                                                            onclick="deleteProduct(<?php echo e($product->id); ?>, '<?php echo e($product->name); ?>')">
                                                        Delete Product
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->doorType->door_type_pretty_name??' '); ?></td>
                                <td>
                                    <?php $__currentLoopData = $product->doorNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index>0): ?>
                                            ,
                                        <?php endif; ?>
                                        <?php echo e($name->door_name_or_type); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                <?php if(isset($products)): ?>
                    <table class="table table-striped" id="product2Table" style="width: 100%">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Product</th>
                            <th>Type</th>
                            <th>Names</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="" style="cursor: pointer" id="rowProductId-<?php echo e($product->id); ?>">
                                <td class="d-none"><?php echo e($product->id); ?></td>
                                <td class="alert-danger delete">
                                    <div data-bs-toggle="modal" data-bs-target="#deleteProduct<?php echo e($product->id); ?>"
                                         style="text-align: center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#FF0000"
                                             class="bi bi-x" viewBox="0 0 16 16">
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                        </svg>
                                    </div>
                                    <div class="modal" id="deleteProduct<?php echo e($product->id); ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Delete Order Request</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Are you sure you want to delete product: <?php echo e($product->name); ?>?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">
                                                        Cancel
                                                    </button>
                                                    <button type="button" class="btn btn-primary"
                                                            onclick="deleteProduct(<?php echo e($product->id); ?>, '<?php echo e($product->name); ?>')">
                                                        Delete Product
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($product->product_name); ?></td>
                                <?php if(isset($product->category)): ?>
                                    <td><?php echo e($product->category->category_name); ?></td>
                                <?php else: ?>
                                    <td>No Category - Update product, bad data</td>
                                <?php endif; ?>
                                <td></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <div class="text-end " style="margin-right: 20px; text-align: right">
            <a href="<?php echo e(route('pcreatedoorflowstepone')); ?>">
                <button class="btn btn-primary mb-3">Add New Product
                </button>
            </a>
        </div>
    </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/product/view.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/zyt84kwukc8i/public_html/qcaspirant/src/resources/views/product/viewdoor.blade.php ENDPATH**/ ?>
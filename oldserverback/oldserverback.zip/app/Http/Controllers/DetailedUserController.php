<?php

namespace App\Http\Controllers;

use App\Models\Address;
use App\Models\Constants;
use App\Models\Distributor;
use App\Models\UserContact;


use App\Models\Manufacturer;
use App\Models\User;
use App\Providers\UserProvider;
use Illuminate\Support\Facades\Hash;
use  Illuminate\Support\Facades\View;
use Illuminate\Validation\Rules\Password;
use Session;


class DetailedUserController extends Controller
{

    public function __construct()
    {
        $usStates = Constants::getStates();
        View::share('usStates', $usStates);

        $this->middleware(['groups:manuf-grp']);
    }

    public function view()
    {
        $users = User::orderby('created_at', 'asc')->get();

        foreach ($users as $user) {
            $user->user_type = UserProvider::getUserType($user);
        }

        return view('user.view',
            ['detailedusers' => $users]
        );
    }

    public function show($id)
    {
        $user = User::findOrFail($id);
        $user->user_type = UserProvider::getUserType($user);

        $distributors = User::join('distributors', 'distributors.user_id', '=', 'users.id')->where(['usertype' => 'distributor', 'users.disabled' => '0'])->select('distributors.*')->get();
        $manufacturers = User::where('usertype', 'manufacturer')->get();
        if (empty($user->address)) {
            $user->address = new Address();
        }

        if($user->user_type == 'distributor'){
            $distributors = Distributor::where('user_id', $user->id)->get();
            if (empty($distributors[0])) {
                $distributors[0] = new Distributor();
            }
            return view('user.viewone',
                ['usermodel' => $user,
                    'contactinfo' => $distributors[0],
                    'manufacturers' => $manufacturers]);
        }
        else{
            $distributor = Distributor::where('user_id', $user->id)->get();
            if (empty($distributor[0])) {
                $distributor[0] = new Distributor();
            }
            return view('user.viewone',
                ['usermodel' => $user,
                    'contactinfo' => $distributor[0],
                    'distributors' => $distributors,
                    'manufacturers' => $manufacturers]);
        }
    }

    public function create()
    {
        return view('user.create', [
                'distributors' => User::where([
                    ['disabled', '=', '0'],
                    ['usertype', '=', 'distributor'],
                ])->get()]
        );
        /*$distributors = User::join('distributors', 'distributors.user_id', '=', 'users.id')->where(['usertype' => 'distributor', 'users.disabled' => '0'])->select('distributors.*')->get();
        return view('user.create', ['distributors' => $distributors]);*/
    }

    public function store()
    {
        $data = request()->all();
        switch ($data['selectedUserType']) {
            case 'distributor':
                $data = request()->validate([
                    'email' => 'required|unique:users',
                    'name' => 'required',
                    'existingUserId' => '',
                    'distributorName' => 'required',
                    'contactPerson' => '',
                    'contactPerson2' => '',
                    'contactPersonPhone' => '',
                    'contactPersonPhone2' => '',
                    'address' => 'required',
                    'address2' => '',
                    'inputCity' => 'required',
                    'state' => 'required',
                    'inputZip' => 'required',
                    'password' => ['required', 'confirmed', Password::min(8)],
                    'passwordConfirm' => '',
                    'selectedUserType' => 'required',
                ]);
                break;
            case 'sales_manager' || 'sales':
                $data = request()->validate([
                    'email' => 'required|unique:users',
                    'name' => 'required',
                    'selectedDistributor' => 'required',
                    'distributorName' => 'required',
                    'contactPerson' => '',
                    'contactPerson2' => '',
                    'contactPersonPhone' => '',
                    'contactPersonPhone2' => '',
                    'address' => 'required',
                    'address2' => '',
                    'inputCity' => 'required',
                    'state' => 'required',
                    'inputZip' => 'required',
                    'password' => ['required', 'confirmed', Password::min(8)],
                    'passwordConfirm' => '',
                    'selectedUserType' => 'required',
                ]);
                break;
            case 'manufacturer':
                $data = request()->validate([
                    'email' => 'required|unique:users',
                    'name' => 'required',
                    'existingUserId' => '',
                    'distributorName' => '',
                    'contactPerson' => '',
                    'contactPerson2' => '',
                    'contactPersonPhone' => '',
                    'contactPersonPhone2' => '',
                    'address' => 'required',
                    'address2' => '',
                    'inputCity' => 'required',
                    'state' => 'required',
                    'inputZip' => 'required',
                    'password' => ['required', 'confirmed', Password::min(8)],
                    'passwordConfirm' => '',
                    'selectedUserType' => 'required',
                ]);
                break;
            default:
                break;
        }

        $this->storeOrCreateUser($data);

        $users = User::orderby('created_at', 'asc')->get();
        Session::flash('success', 'Successfully Added / Updated ');
        return view('user.view',
            ['detailedusers' => $users,
            ]
        );
    }

    public function update()
    {
        $data = request()->all();
        if (isset($data['inputZip']) || isset($data['address'])
            || isset($data['address2']) || isset($data['inputCity'])
            || isset($data['state'])) {
            $data = request()->validate([
                'email' => 'required',
                'selectedUserType' => '',
                'name' => 'required',
                'existingUserId' => '',
                'selectedDistributor' => '',
                'distributorName' => '',
                'contactPerson' => '',
                'contactPerson2' => '',
                'contactPersonPhone' => '',
                'contactPersonPhone2' => '',
                'address' => 'required',
                'address2' => '',
                'inputCity' => 'required',
                'state' => 'required',
                'inputZip' => 'required',
            ]);
        } else {
            $data = request()->validate([
                'email' => 'required',
                'selectedUserType' => '',
                'name' => 'required',
                'existingUserId' => '',
                'selectedDistributor' => '',
                'distributorName' => '',
                'contactPerson' => '',
                'contactPerson2' => '',
                'contactPersonPhone' => '',
                'contactPersonPhone2' => '',
                'address' => '',
                'address2' => '',
                'inputCity' => '',
                'state' => '',
                'inputZip' => '',
            ]);
        }
        $this->storeOrCreateUser($data);

        $users = User::orderby('created_at', 'asc')->get();

        return view('user.view',
            ['detailedusers' => $users]
        );
    }

    /**
     * Enable or disable a user.
     *
     * @param $id
     * @return void
     */
    public function toggle($id)
    {
        $user = auth()->user();
        if ($user->id == $id) {
            return back()->with('error', 'You cannot disable your own account!!!');
        }

        $targetedUser = User::findOrFail($id);
        if ($targetedUser->disabled) {
            $targetedUser->update(['disabled' => false]);
        } else {
            $targetedUser->update(['disabled' => true]);
        }

        return back()->with('success', $targetedUser->email . ' account updated!');
    }

    private function storeOrCreateUser(array $data)
    {

        $auser = '';
        $address = '';

        if (array_key_exists('existingUserId', $data)) {
            $auser = User::findOrFail($data['existingUserId']);
            //$this->authorize('update', $existingUser);
            $auser->update(
                ['name' => $data['name'],
                ]);
        } else {
            $data['password'] = Hash::make($data['password']);
            $auser = User::create($data);
        }

        if (isset($data['inputZip']) || isset($data['address'])
            || isset($data['address2']) || isset($data['inputCity'])
            || isset($data['state'])) {
            $addressArray = Address::where('user_id', $auser->id)->get();
            if (sizeof($addressArray) > 0) {
                $addressArray[0]->update([
                    'address' => $data['address'],
                    'address2' => $data['address2'],
                    'city' => $data['inputCity'],
                    'state' => $data['state'],
                    'postal_code' => $data['inputZip'],
                ]);
                $address = $addressArray[0];
            } else {
                $address = Address::create([
                    'user_id' => $auser->id,
                    'address' => $data['address'],
                    'address2' => $data['address2'],
                    'city' => $data['inputCity'],
                    'state' => $data['state'],
                    'postal_code' => $data['inputZip']
                ]);
            }
        }

        if (array_key_exists('selectedUserType', $data)) {
            $auser->usertype = $data['selectedUserType'];
            $auser->save();

            $distributor = '';
            $distributorArray = UserContact::where('user_id', $auser->id)->get();
            if (empty($distributorArray[0])) {
                $distributor =
                    UserContact::create([
                        'user_id' => $auser->id,
                        'distributor_name' => $data['distributorName'],
                        'shipping_address_id' => $address->id,
                        'physical_address_id' => 0,
                        'credit_limit' => 0,
                        'payment_term' => 'net 30',
                    ]);
            } else {
                $distributor = $distributorArray[0];
                $distributor->update([
                    'distributor_name' => $data['distributorName'],
                    'shipping_address_id' => $address->id,
                ]);
            }
            if (isset($data['contactPerson'])) {
                $distributor->update([
                    'primary_contact' => $data['contactPerson'],
                ]);
            }

            if (isset($data['contactPersonPhone'])) {
                $distributor->update([
                    'primary_phone' => $data['contactPersonPhone'],
                ]);
            }

            if (isset($data['contactPerson2'])) {
                $distributor->update([
                    'secondary_contact' => $data['contactPerson2'],
                ]);
            }

            if (isset($data['contactPersonPhone2'])) {
                $distributor->update([
                    'secondary_phone' => $data['contactPersonPhone2'],
                ]);
            }

            switch ($data['selectedUserType']) {
                case 'distributor':
                    $auser->assignGroup(['distributor-grp']);
                    break;
                case 'sales_manager':
                    $auser->assignGroup(['slsmgr-grp']);
                    if(isset($data['selectedDistributor']))
                        $auser->update(['distributor_id' => $data['selectedDistributor']]);
                    break;
                case 'sales':
                    $auser->assignGroup(['sales-grp']);
                    if(isset($data['selectedDistributor']))
                        $auser->update(['distributor_id' => $data['selectedDistributor']]);
                    break;
                case 'dealer':
                    $auser->assignGroup(['dealer-grp']);
                    if(isset($data['selectedDistributor']))
                        $auser->update(['distributor_id' => $data['selectedDistributor']]);
                    break;

            }
        }

    }

    // useing distributor table
    private function storeOrCreateUser_bkkk(array $data)
    {

        $auser = '';
        $address = '';

        if (array_key_exists('existingUserId', $data)) {
            $auser = User::findOrFail($data['existingUserId']);
            //$this->authorize('update', $existingUser);
            $auser->update(
                ['name' => $data['name'],
                ]);
        } else {
            $data['password'] = Hash::make($data['password']);
            $auser = User::create($data);
        }

        if (isset($data['inputZip']) || isset($data['address'])
            || isset($data['address2']) || isset($data['inputCity'])
            || isset($data['state'])) {
            $addressArray = Address::where('user_id', $auser->id)->get();
            if (sizeof($addressArray) > 0) {
                $addressArray[0]->update([
                    'address' => $data['address'],
                    'address2' => $data['address2'],
                    'city' => $data['inputCity'],
                    'state' => $data['state'],
                    'postal_code' => $data['inputZip'],
                ]);
                $address = $addressArray[0];
            } else {
                $address = Address::create([
                    'user_id' => $auser->id,
                    'address' => $data['address'],
                    'address2' => $data['address2'],
                    'city' => $data['inputCity'],
                    'state' => $data['state'],
                    'postal_code' => $data['inputZip']
                ]);
            }
        }

        if (array_key_exists('selectedUserType', $data)) {
            $auser->usertype = $data['selectedUserType'];
            $auser->save();

            $distributor = '';
            $distributorArray = Distributor::where('user_id', $auser->id)->get();
            if (empty($distributorArray[0])) {
                $distributor =
                    Distributor::create([
                        'user_id' => $auser->id,
                        'distributor_name' => $data['distributorName'],
                        'shipping_address_id' => $address->id,
                        'physical_address_id' => 0,
                        'credit_limit' => 0,
                        'payment_term' => 'net 30',
                    ]);
            } else {
                $distributor = $distributorArray[0];
                $distributor->update([
                    'distributor_name' => $data['distributorName'],
                    'shipping_address_id' => $address->id,
                ]);
            }
            if (isset($data['contactPerson'])) {
                $distributor->update([
                    'primary_contact' => $data['contactPerson'],
                ]);
            }

            if (isset($data['contactPersonPhone'])) {
                $distributor->update([
                    'primary_phone' => $data['contactPersonPhone'],
                ]);
            }

            if (isset($data['contactPerson2'])) {
                $distributor->update([
                    'secondary_contact' => $data['contactPerson2'],
                ]);
            }

            if (isset($data['contactPersonPhone2'])) {
                $distributor->update([
                    'secondary_phone' => $data['contactPersonPhone2'],
                ]);
            }

            switch ($data['selectedUserType']) {
                case 'distributor':
                    $auser->assignGroup(['distributor-grp']);
                    break;
                case 'sales_manager':
                    $auser->assignGroup(['slsmgr-grp']);
                    if(isset($data['selectedDistributor']))
                        $auser->update(['distributor_id' => $data['selectedDistributor']]);
                    break;
                case 'sales':
                    $auser->assignGroup(['sales-grp']);
                    if(isset($data['selectedDistributor']))
                        $auser->update(['distributor_id' => $data['selectedDistributor']]);
                    break;
                case 'dealer':
                    $auser->assignGroup(['dealer-grp']);
                    if(isset($data['selectedDistributor']))
                        $auser->update(['distributor_id' => $data['selectedDistributor']]);
                    break;

            }
        }

    }

}

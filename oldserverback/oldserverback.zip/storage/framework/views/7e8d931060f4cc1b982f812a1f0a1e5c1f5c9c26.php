<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('User Management')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <form class=" g-3" action="/u/update" method="POST">
        <?php echo csrf_field(); ?>

        <input type="hidden" class="" id="selectedUserType" name="selectedUserType" value="<?php echo e($usermodel->usertype); ?>">
        <input type="hidden" name="existingUserId" value="<?php echo e($usermodel->id); ?>">

        <div class="container py-4">
            <h4 style="text-align: center">User Details</h4>
            <?php if($usermodel->usertype=='sales'): ?>
                <p style="text-align: center; text-transform: capitalize; font-variant: small-caps; ">Sales User</p>
            <?php elseif($usermodel->usertype=='slsmgr'): ?>
                <p style="text-align: center; text-transform: capitalize; font-variant: small-caps; ">Sales Manager
                    User</p>
            <?php elseif($usermodel->usertype=='distributor'): ?>
                <p style="text-align: center; text-transform: capitalize; font-variant: small-caps; ">Distributor
                    User</p>
            <?php elseif($usermodel->usertype=='dealer'): ?>
                <p style="text-align: center; text-transform: capitalize; font-variant: small-caps; ">Dealer
                    User</p>
            <?php elseif($usermodel->usertype=='manufacturer'): ?>
                <p style="text-align: center; text-transform: capitalize; font-variant: small-caps; ">Manufacturer
                    User</p>
            <?php endif; ?>
            <hr/>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row flex m-3">
                    <span class="" role="alert" style="color: red">
                                        <strong><?php echo e($error); ?></strong>
                                    </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo session('success'); ?>

                </div>
            <?php endif; ?>

            <div class="container">
                <div class="row standardUser p-1 m-1">
                    <div class="col-1 mt-1">
                        <label for="email" class="form-label">Email</label>
                    </div>
                    <div class="col">
                        <input type="email"
                               readonly
                               class="form-control<?php echo e($errors->has('email') ? ' is-invalid': ''); ?>"
                               id="email"
                               name="email"
                               autocomplete="email"
                               value="<?php echo e($usermodel->email); ?>">
                    </div>
                    <div class="col-1 mt-1">
                        <label for="name" class="form-label">Name</label>
                    </div>
                    <div class="col ">
                        <input type="text"
                               class="form-control<?php echo e($errors->has('name') ? ' is-invalid': ''); ?>"
                               id="name"
                               name="name"
                               autocomplete="name"
                               value="<?php echo e($usermodel->name); ?>">
                    </div>
                </div>
                <?php if($usermodel->usertype == 'distributor'): ?>
                    <div class="row  standardUser p-1 m-1">
                        <div class="col-4 mt-1">
                            <label for="associated_manufacturer" class="form-label">Associated Manufacturer</label>
                        </div>
                        <div class="col">
                            <select name="associated_manufacturer"
                                    class="form-select form-control">
                                <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($manufacturer): ?>
                                        <?php if($manufacturer->id == $usermodel->associated_manufacturer): ?>
                                            <option selected
                                                    value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->name); ?>

                                                - <?php echo e($manufacturer->email); ?></option>
                                        <?php else: ?>
                                            <option
                                                value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->name); ?>

                                                - <?php echo e($manufacturer->email); ?></option>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                <?php elseif($usermodel->usertype=='manufacturer'): ?>
                    <div class="row  standardUser p-1 m-1">
                        <div class="col-2 mt-1">
                            <label for="name" class="form-label">User Info</label>
                        </div>
                        <div class="col mt-1">
                            <p>This is a manufacturer user and has editing limitations.</p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($usermodel->usertype!='distributor' && $usermodel->usertype != 'manufacturer'): ?>
                    <div class="row  standardUser m-1 p-1 ">
                        <div class="col-4 mt-1">
                            <label for="selectedDistributor" class="form-label">Select Distributor</label>
                        </div>
                        <div class="col">
                            <select name="selectedDistributor"
                                    class="form-select form-control">
                                <?php $__currentLoopData = $distributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($distributor): ?>
                                        <?php if($distributor->user_id == $usermodel->distributor_id): ?>
                                            <option selected
                                                value="<?php echo e($distributor->user_id); ?>"><?php echo e($distributor->distributor_name); ?></option>
                                        <?php else: ?>
                                            <option
                                                value="<?php echo e($distributor->user_id); ?>"><?php echo e($distributor->distributor_name); ?></option>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                <?php endif; ?>

                    <div class="row distributorUser m-1 p-1">
                        <div class="col-4 mt-1">
                            Distributor Name
                        </div>
                        <div class="col">
                            <input type="text" class="form-control"
                                   name="distributorName" id="distributorName"
                                   value="<?php echo e($contactinfo->distributor_name??old('distributorName')); ?>">
                        </div>
                    </div>
                    <div class="row   distributorUser m-1 p-1">
                        <div class="col-4 mt-1">
                            <label for="contactPerson" class="form-label">Contact Person</label>
                        </div>
                        <div class="col">
                            <input type="text"
                                   class="form-control<?php echo e($errors->has('contactPerson')?' is-invalid': ''); ?>"
                                   id="contactPerson"
                                   name="contactPerson"
                                   value="<?php echo e($contactinfo->primary_contact??old('contactPerson')); ?>">
                        </div>
                    </div>
                    <div class="row   distributorUser p-1 m-1">
                        <div class="col-4 mt-1">
                            <label for="contactPersonPhone" class="form-label">Contact Phone</label>
                        </div>
                        <div class="col">
                            <input type="tel"
                                   class="form-control<?php echo e($errors->has('contactPersonPhone')?' is-invalid': ''); ?>"
                                   id="contactPersonPhone"
                                   name="contactPersonPhone"
                                   value="<?php echo e($contactinfo->primary_phone??old('contactPersonPhone')); ?>">

                        </div>
                    </div>
                    <div class="row   distributorUser p-1 m-1">
                        <div class="col-4 mt-1">
                            <label for="contactPerson2" class="form-label">Alt. Contact Person</label>
                        </div>
                        <div class="col">
                            <input type="text"
                                   class="form-control<?php echo e($errors->has('contactPerson2')?' is-invalid': ''); ?>"
                                   id="contactPerson2"
                                   name="contactPerson2"
                                   value="<?php echo e($contactinfo->secondary_contact??old('contactPerson2')); ?>">
                        </div>
                    </div>
                    <div class="row   distributorUser p-1 m-1">
                        <div class="col-4 mt-1">
                            <label for="contactPersonPhone2" class="form-label">Alt. Contact Phone</label>
                        </div>
                        <div class="col">
                            <input type="tel"
                                   class="form-control<?php echo e($errors->has('contactPersonPhone2')?' is-invalid': ''); ?>"
                                   id="contactPersonPhone2"
                                   name="contactPersonPhone2"
                                   value="<?php echo e($contactinfo->secondary_phone??old('contactPersonPhone2')); ?>">
                        </div>
                    </div>

                <fieldset>
                    <legend>Shipping Address</legend>
                    <div class="row distributorUser p-1 m-1">
                        <div class="col-3 mt-1">
                            <label for="address" class="form-label">Address</label>
                        </div>
                        <div class="col">
                            <input type="text"
                                   class="form-control<?php echo e($errors->has('address')?' is-invalid':''); ?>"
                                   id="address"
                                   name="address"
                                   placeholder="1234 Main St"
                                   value="<?php echo e($usermodel->address->address??old('address')); ?>">
                        </div>
                    </div>
                    <div class="row distributorUser m-1 p-1">
                        <div class="col-3 mt-1">
                            <label for="address2" class="form-label">Address 2</label>
                        </div>
                        <div class="col">
                            <input type="text"
                                   class="form-control<?php echo e($errors->has('address2')?' is-invalid':''); ?>"
                                   id="address2"
                                   name="address2"
                                   placeholder="Suite #123B"
                                   value="<?php echo e($usermodel->address->address2??old('address2')); ?>">
                        </div>
                    </div>
                    <div class="row distributorUser m-1 p-1">
                        <div class="col-1 mt-1">
                            <label for="inputCity" class="form-label">City</label>
                        </div>
                        <div class="col-3">
                            <input type="text" class="form-control" id="inputCity" name="inputCity"
                                   value="<?php echo e($usermodel->address->city??old('inputCity')); ?>">
                        </div>
                        <div class="col-1 mt-1">
                            <label for="state" class="form-label">State</label>
                        </div>
                        <div class="col">
                            <select id="state" name="state" class="form-select form-control">
                                <?php $__currentLoopData = $usStates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(trim($state) == trim($usermodel->address->state)): ?>
                                        <option selected value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($state); ?>"><?php echo e($state); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <option value="Taxes">Taxes</option>
                            </select>
                        </div>
                        <div class="col-1 mt-1">
                            <label for="inputZip" class="form-label">Zip</label>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" id="inputZip" name="inputZip"
                                   value="<?php echo e($usermodel->address->postal_code); ?>">
                        </div>
                    </div>
                </fieldset>
            </div>

        </div>

        <div class="row bottom-button-bar">
            <div class="col">
                <button class="btn btn-primary" id="saveUserUpdatesButton">Save User Updates</button>
            </div>
        </div>
    </form>
    <?php $__env->startSection('scripts'); ?>
        <script>
            window.onload = function () {


            }
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/user/viewone.blade.php ENDPATH**/ ?>
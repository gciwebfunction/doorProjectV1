<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Order Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container py-4">
        <h4 style="text-align: center">Order Requests</h4>

        <?php if(isset($message) && strlen($message)>0): ?>
            <div class="container">
                <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                </div>
            </div>
        <?php endif; ?>

        <div id="container">
            <table class="table-striped" id="orderRequestTable">
                <thead>
                <tr>
                    <th></th>
                    <th>
                        Request #
                    </th>
                    <th>
                        Date Created
                    </th>
                    <th>
                        PO
                    </th>
                    <th>
                        Order Total
                    </th>
                    <th>
                        STATUS
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $oRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="alert-danger">
                            <div data-bs-toggle="modal" data-bs-target="#deleteOrderRequest<?php echo e($or->id); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#FF0000"
                                     class="bi bi-x" viewBox="0 0 16 16">
                                    <path
                                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                </svg>
                            </div>
                            <div class="modal" id="deleteOrderRequest<?php echo e($or->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Order Request</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete order request number #<?php echo e($or->id); ?>?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                Cancel
                                            </button>
                                            <button type="button" class="btn btn-primary"
                                                    onclick="deleteOrderRequest(<?php echo e($or->id); ?>)">Delete Order Request
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($or->id); ?></td>
                        <td><?php echo e($or->created_at); ?></td>
                        <td><?php echo e($or->po_number); ?></td>
                        <td><?php echo e(sprintf('%0.12f',$or->total)); ?></td>

                        <?php if($or->status == 'NOT SUBMITTED'): ?>
                            <td class="alert-danger"><?php echo e($or->status); ?><br/><a href="/or/submit/<?php echo e($or->id); ?>"
                                                                            style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 2px">SUBMIT</a>
                            </td>
                        <?php elseif($or->status == 'PENDING CONFIRMATION'): ?>
                            <td class="alert-warning">
                                <?php echo e($or->status); ?>

                            </td>
                        <?php else: ?>
                            <td>
                                <?php echo e($or->status); ?>

                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/orderrequest/view.js')); ?>" defer></script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/orderrequest/view.blade.php ENDPATH**/ ?>
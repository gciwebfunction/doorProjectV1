/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************************************!*\
  !*** ./resources/js/shoppingcart/cartviewdoor.js ***!
  \***************************************************/
window.onload = function () {
  $('#otherCartTable').DataTable();
  $('#cartTable').DataTable();
  document.getElementById('goBackToCatalogButton').addEventListener('click', function (event) {
    event.preventDefault();
    window.location = "/dashboard";
  });
  document.getElementById('clearCart').addEventListener('click', function (event) {
    event.preventDefault();
    var cartId = $('#shoppingCartId').val();
    window.location = "/sc/clearcart/" + cartId;
  });
  document.getElementById('submitOrderButton').addEventListener('click', function (event) {
    event.preventDefault();
    $('#cartForm').submit();
  });
  $('.delete').each(function () {
    this.addEventListener('click', function (event) {
      var id = this.id.split('-')[1];
      $('#divFloat').text('Deleting item...');
      $('#centerFloatDiv').removeClass('d-none');
      $.get('/sc/deleteDoorItem/' + id).done(function () {
        $('#itemRow1-' + id).remove();
        $('#itemRow2-' + id).remove();
        $('#itemRow3-' + id).remove();
        $('#message').append('<p>Deleted item!</p>');
      }).fail(function () {
        $('#message').append('<p style="color:red">Deleting item failed.</p>');
      }).always(function () {
        $('#divFloat').text('');
        $('#centerFloatDiv').addClass('d-none');
      });
    });
  });
};
/******/ })()
;
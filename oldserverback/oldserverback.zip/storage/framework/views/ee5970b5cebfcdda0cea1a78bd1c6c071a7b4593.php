<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Manufacturer Dashboard')); ?>

     <?php $__env->endSlot(); ?>
    <div class="container py-4">


        <section class="py-5 text-center container">
            <div class="row py-lg-5">
                <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light">Product Catalog</h1>
                    <p class="lead text-muted">Products are detailed below. Please click a link to initiate the order
                        process for a product.</p>
                    <p>
                        <a href="#" class="btn btn-primary my-2">Current Order Status</a>
                        <a href="#" class="btn btn-secondary my-2">In Progress Orders</a>
                    </p>
                </div>
            </div>
        </section>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $doorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($t->category_id == $category->id): ?>
                    <?php $__currentLoopData = $t->doors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $door): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row m-3 py-4" style="border: 1px solid lightgrey; border-radius: 5px; box-shadow: #adb5bd; margin-right: auto"   >
                            <div class="col-5 text-right"><img src="/storage/<?php echo e($category->image->image_path); ?>"
                                                             alt="<?php echo e($category->category_name); ?>"
                                                             class=" "
                                                             style="max-width:430px;  max-height:444px;  width: auto;  height: auto; ">
                            </div>
                            <div class="col-4">
                                <h4><?php echo e($door->name); ?></h4>
                                <p class="card-text"><?php echo e($category->category_name); ?>

                                    - <?php echo e($category->category_note); ?></p>
                            </div>
                            <div class="col-3" style="text-align: center; vertical-align: bottom">
                                <p class="p-3 mb-5">

                                </p>
                                <button type="button" class="btn btn-lg"
                                        onclick="window.location = '/sc/door/<?php echo e($shoppingCart->id); ?>/<?php echo e($door->id); ?>'">Order
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($t->category_id == $category->id): ?>

                        <div class="row m-3 py-4" style="border: 1px solid lightgrey; border-radius: 5px; box-shadow: #adb5bd; margin-right: auto"   >
                            <div class="col-5 text-right"><img src="/storage/<?php echo e($category->image->image_path); ?>"
                                                               alt="<?php echo e($category->category_name); ?>"
                                                               class=" "
                                                               style="max-width:430px;  max-height:444px;  width: auto;  height: auto; ">
                            </div>
                            <div class="col-4">
                                <h4><?php echo e($t->product_name); ?></h4>
                                <p class="card-text"><?php echo e($category->category_name); ?>

                                    - <?php echo e($category->category_note); ?></p>
                            </div>
                            <div class="col-3" style="text-align: center; vertical-align: bottom">
                                <p class="p-3 mb-5">

                                </p>
                                <button type="button" class="btn btn-lg"
                                        onclick="window.location = '/sc/product/<?php echo e($shoppingCart->id); ?>/<?php echo e($t->id); ?>'">Order
                                </button>
                            </div>
                        </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

    <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo e(asset('js/dashboard/manufdash.js')); ?>" defer></script>
        <script>
            $(document).ready(function () {
                $('#manufOrderTable').DataTable();
            });
        </script>
    <?php $__env->stopSection(); ?>

     <?php $__env->slot('footer', null, []); ?> 
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/dashboard.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Order Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container py-4">
        <h4 style="text-align: center">Current Orders</h4>
        <div class="container">
            <table class="table-striped" id="orderTable">
                <thead>
                <tr>
                    <th>
                        Order Date
                    </th>
                    <th>
                        Order Total
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Print
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php if(@isset($orders)): ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->created_at); ?></td>
                            <td class="currSign">
                                <?php echo e(sprintf('%01.2f', $order->total_order_amount)); ?>



                            </td>
                            <td>CREATED</td>
                            <td>

                                <a title="Print Order" href="/o/Orprint/<?php echo e($order->id); ?>" target="_blank"
                                   style="text-align:center;border-radius: 2px; border: 1px solid black; background-color: lightgray;margin-left: 11px; "><img src="/img/printicon.png" ></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <h4 style="text-align: center">Current Order Requests</h4>
        <div class="container">
            <table class="table-striped" id="orderRequestTable">
                <thead>
                <tr>
                    <th></th>
                    <th>Request #</th>
                    <th>Date Created</th>
                    <th>PO</th>
                    <th>Order Total</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $oRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="alert-danger">
                            <div data-bs-toggle="modal" data-bs-target="#deleteOrderRequest<?php echo e($or->id); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="#FF0000"
                                     class="bi bi-x" viewBox="0 0 16 16">
                                    <path
                                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                </svg>
                            </div>
                            <div class="modal" id="deleteOrderRequest<?php echo e($or->id); ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Delete Order Request</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete order request number #<?php echo e($or->id); ?>?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                Cancel
                                            </button>
                                            <button type="button" class="btn btn-primary"
                                                    onclick="deleteOrderRequest(<?php echo e($or->id); ?>)">Delete Order Request
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php echo e($or->id); ?>

                        </td>
                        <td>
                            <?php echo e($or->created_at); ?>

                        </td>
                        <td>
                            <?php echo e($or->po_number); ?>

                        </td>
                        <td class="currSign">

                            <?php echo e(sprintf('%01.2f', $or->total)); ?>

                        </td>
                        <td>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($or->status == $s->id): ?>
                                    <?php echo e($s->status); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/Editmanufacturerdetailview/<?php echo e($or->id); ?>">
                                View
                            </a>
                            <?php if($user->usertype == 'manufacturer' &&  $or->current_level == 3 && $or->request_type == '3 level' ): ?>
                                |<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/editManufacturerform/<?php echo e($or->id); ?>">Edit</a>|<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/editManufacturereqconfirm/<?php echo e($or->id); ?>">Confirm</a>
                            <?php endif; ?>

                            <?php if($user->usertype == 'distributor' &&  $or->current_level == 4 && $or->request_type == '3 level' ): ?>
                                |<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/editManufacturerform/<?php echo e($or->id); ?>">Edit</a>|<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/editManufacturereqconfirm/<?php echo e($or->id); ?>">Confirm</a>
                            <?php endif; ?>


                            <?php if($user->usertype == 'dealer' &&  $or->current_level == 5 &&  $or->request_type == '3 level'  ): ?>
                                |<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/editManufacturerform/<?php echo e($or->id); ?>">Edit</a>|<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/orderReqconfirm/<?php echo e($or->id); ?>">Confirm</a>|<a style="border-radius: 2px; border: 1px solid black; background-color: lightgray; padding: 3px" href="/o/rejectOrderrequest/<?php echo e($or->id); ?>">Reject</a>
                            <?php endif; ?>

                        </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/order/view.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/doorv3/src/resources/views/order/view.blade.php ENDPATH**/ ?>